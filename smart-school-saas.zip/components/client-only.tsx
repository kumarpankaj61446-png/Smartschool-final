"use client"

import dynamic from "next/dynamic"
import type { ReactNode } from "react"

interface ClientOnlyProps {
  children: ReactNode
  fallback?: ReactNode
}

const ClientOnly = ({ children, fallback = null }: ClientOnlyProps) => {
  return <>{children}</>
}

export default dynamic(() => Promise.resolve(ClientOnly), {
  ssr: false,
})
