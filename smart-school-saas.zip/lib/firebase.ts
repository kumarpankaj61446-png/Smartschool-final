import type { FirebaseApp } from "firebase/app"
import type { Auth } from "firebase/auth"
import type { Firestore } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyDpTqOoormbeptr7LRYZ0x8VRQolG6IoJw",
  authDomain: "smartschool-saas.firebaseapp.com",
  projectId: "smartschool-saas",
  storageBucket: "smartschool-saas.firebasestorage.app",
  messagingSenderId: "1090252430119",
  appId: "1:1090252430119:web:dbc677322de90eb08de702",
  measurementId: "G-M57ZSF8EVR",
}

let app: FirebaseApp | null = null
let auth: Auth | null = null
let db: Firestore | null = null

// Lazy initialization functions
export const getFirebaseApp = async (): Promise<FirebaseApp> => {
  if (typeof window === "undefined") {
    throw new Error("Firebase can only be initialized on the client side")
  }

  if (!app) {
    const { initializeApp, getApps } = await import("firebase/app")
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0]
  }
  return app
}

export const getFirebaseAuth = async (): Promise<Auth> => {
  if (typeof window === "undefined") {
    throw new Error("Firebase Auth can only be initialized on the client side")
  }

  if (!auth) {
    const firebaseApp = await getFirebaseApp()
    const { initializeAuth, browserLocalPersistence, getAuth } = await import("firebase/auth")

    try {
      // Try to get existing auth instance first
      auth = getAuth(firebaseApp)
    } catch (error) {
      // If no auth instance exists, initialize it properly
      auth = initializeAuth(firebaseApp, {
        persistence: browserLocalPersistence,
      })
    }
  }
  return auth
}

export const getFirebaseDb = async (): Promise<Firestore> => {
  if (typeof window === "undefined") {
    throw new Error("Firebase Firestore can only be initialized on the client side")
  }

  if (!db) {
    const firebaseApp = await getFirebaseApp()
    const { getFirestore } = await import("firebase/firestore")
    db = getFirestore(firebaseApp)
  }
  return db
}

// User roles enum
export enum UserRole {
  PRINCIPAL = "principal",
  TEACHER = "teacher",
  STUDENT = "student",
  PARENT = "parent",
}

// User profile interface
export interface UserProfile {
  uid: string
  email: string
  role: UserRole
  name: string
  schoolId?: string
  createdAt: Date
  lastLogin?: Date
}
