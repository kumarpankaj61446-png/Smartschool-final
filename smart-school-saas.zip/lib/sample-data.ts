// Sample data for the application

export const sampleStudents = [
  { id: 1, name: "Alice Johnson", grade: "10th", attendance: 95, fees: "Paid" },
  { id: 2, name: "Bob Smith", grade: "9th", attendance: 88, fees: "Pending" },
  { id: 3, name: "Carol Davis", grade: "11th", attendance: 92, fees: "Paid" },
  { id: 4, name: "David Wilson", grade: "10th", attendance: 85, fees: "Overdue" },
]

export const sampleTeachers = [
  { id: 1, name: "Dr. Sarah Brown", subject: "Mathematics", classes: 5, students: 150 },
  { id: 2, name: "Mr. John Miller", subject: "English", classes: 4, students: 120 },
  { id: 3, name: "Ms. Emily Chen", subject: "Science", classes: 6, students: 180 },
]

export const sampleAttendance = [
  { date: "2024-01-15", present: 145, absent: 15, total: 160 },
  { date: "2024-01-16", present: 152, absent: 8, total: 160 },
  { date: "2024-01-17", present: 148, absent: 12, total: 160 },
  { date: "2024-01-18", present: 155, absent: 5, total: 160 },
  { date: "2024-01-19", present: 150, absent: 10, total: 160 },
]

export const sampleFinancialData = [
  { month: "Jan", revenue: 45000, expenses: 32000, profit: 13000 },
  { month: "Feb", revenue: 48000, expenses: 34000, profit: 14000 },
  { month: "Mar", revenue: 52000, expenses: 36000, profit: 16000 },
  { month: "Apr", revenue: 49000, expenses: 35000, profit: 14000 },
  { month: "May", revenue: 55000, expenses: 38000, profit: 17000 },
  { month: "Jun", revenue: 58000, expenses: 40000, profit: 18000 },
]

export const features = [
  {
    title: "Smart Attendance (QR)",
    description: "Quick and accurate attendance tracking using QR codes",
    icon: "QrCode",
  },
  {
    title: "Fee Management + Online Payments",
    description: "Streamlined fee collection with integrated payment gateway",
    icon: "CreditCard",
  },
  {
    title: "Homework Manager",
    description: "Assign, track, and grade homework efficiently",
    icon: "BookOpen",
  },
  {
    title: "Student Progress Tracker",
    description: "Monitor and analyze student performance over time",
    icon: "TrendingUp",
  },
  {
    title: "Parent Communication App",
    description: "Direct communication channel between school and parents",
    icon: "MessageCircle",
  },
  {
    title: "AI Lesson Planner",
    description: "AI-powered lesson planning and curriculum management",
    icon: "Brain",
  },
  {
    title: "AI Study Buddy",
    description: "Personalized AI tutor for student learning support",
    icon: "Bot",
  },
  {
    title: "Gamified Learning",
    description: "Engaging learning experience with rewards and achievements",
    icon: "Trophy",
  },
  {
    title: "White-label App (Premium)",
    description: "Customizable branded mobile app for your school",
    icon: "Smartphone",
  },
]
