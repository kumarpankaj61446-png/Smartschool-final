import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Clock, TrendingUp, MessageSquare, DollarSign, Play, Users, BookOpen } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative py-12 md:py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-950/20 dark:to-indigo-950/20" />
        <div className="container relative z-10 px-4">
          <div className="max-w-4xl mx-auto text-center space-y-6 md:space-y-8">
            <Badge variant="secondary" className="mb-4">
              🎉 2 Months Free Access - Limited Time Offer
            </Badge>

            <h1 className="text-3xl md:text-4xl lg:text-6xl font-bold text-balance bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 bg-clip-text text-transparent animate-fade-in">
              One Platform for Principals, Teachers, Students & Parents
            </h1>

            <p className="text-lg md:text-xl lg:text-2xl text-muted-foreground text-balance animate-slide-up">
              Smart School SaaS – Manage Attendance, Fees, Homework, AI Tools, and Communication in one place.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-base md:text-lg px-6 md:px-8 py-4 md:py-6"
              >
                Book a Free Demo
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-base md:text-lg px-6 md:px-8 py-4 md:py-6 bg-transparent"
              >
                Start Free Trial (2 Months Free Access)
              </Button>
            </div>

            {/* Demo Video Placeholder */}
            <div className="mt-8 md:mt-12 relative max-w-4xl mx-auto">
              <div className="aspect-video bg-gradient-to-br from-blue-100 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-2xl border-2 border-blue-200 dark:border-blue-800 flex items-center justify-center group cursor-pointer hover:scale-105 transition-transform duration-300">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 md:w-20 md:h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto group-hover:bg-blue-700 transition-colors">
                    <Play className="w-6 h-6 md:w-8 md:h-8 text-white ml-1" />
                  </div>
                  <p className="text-base md:text-lg font-medium text-blue-700 dark:text-blue-300">Watch Demo Video</p>
                  <p className="text-sm text-muted-foreground">See how Smart School transforms education management</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-12 md:py-20 bg-muted/30">
        <div className="container px-4">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4">Why Choose Smart School?</h2>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Transform your educational institution with our comprehensive platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Save Time</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Automate administrative tasks and focus on what matters most - education
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">Boost Learning</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  AI-powered tools and gamification enhance student engagement and performance
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="w-8 h-8 text-purple-600" />
                </div>
                <CardTitle className="text-xl">Transparent Communication</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Keep parents informed with real-time updates and direct communication channels
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="w-8 h-8 text-orange-600" />
                </div>
                <CardTitle className="text-xl">Timely Fee Collection</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Streamlined fee management with automated reminders and online payments
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Preview */}
      <section className="py-12 md:py-20">
        <div className="container px-4">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4">Powerful Features</h2>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Everything you need to manage your school efficiently
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                  <CardTitle className="text-lg">Smart Attendance</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>QR code-based attendance system for quick and accurate tracking</CardDescription>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-green-600" />
                  </div>
                  <CardTitle className="text-lg">Fee Management</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Integrated payment gateway with automated fee collection and reminders
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-purple-600" />
                  </div>
                  <CardTitle className="text-lg">AI Study Tools</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>AI-powered lesson planning and personalized study assistance</CardDescription>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8 md:mt-12">
            <Button asChild size="lg" variant="outline">
              <Link href="/features">View All Features</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="container text-center px-4">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4">Ready to Transform Your School?</h2>
          <p className="text-lg md:text-xl mb-6 md:mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of schools already using Smart School to improve education management
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-base md:text-lg px-6 md:px-8 py-4 md:py-6">
              Book a Free Demo
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-base md:text-lg px-6 md:px-8 py-4 md:py-6 border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              Start Free Trial
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
