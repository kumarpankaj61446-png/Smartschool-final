"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { FinancialDashboard } from "@/modules/financial-dashboard"
import { Button } from "@/components/ui/button"
import { BarChart3, Settings, Users, GraduationCap, UserCheck, DollarSign, FileText } from "lucide-react"
import Link from "next/link"

function PrincipalSidebar() {
  return (
    <nav className="p-4 space-y-2">
      <div className="px-3 py-2">
        <h2 className="mb-2 px-4 text-lg font-semibold">Principal Dashboard</h2>
      </div>

      <div className="space-y-1">
        <Button variant="ghost" className="w-full justify-start" asChild>
          <Link href="/dashboard/principal">
            <BarChart3 className="mr-2 h-4 w-4" />
            Overview
          </Link>
        </Button>
        <Button variant="ghost" className="w-full justify-start" asChild>
          <Link href="/dashboard/principal/students">
            <Users className="mr-2 h-4 w-4" />
            Students
          </Link>
        </Button>
        <Button variant="ghost" className="w-full justify-start" asChild>
          <Link href="/dashboard/principal/teachers">
            <GraduationCap className="mr-2 h-4 w-4" />
            Teachers
          </Link>
        </Button>
        <Button variant="ghost" className="w-full justify-start" asChild>
          <Link href="/dashboard/principal/attendance">
            <UserCheck className="mr-2 h-4 w-4" />
            Attendance
          </Link>
        </Button>
        <Button variant="default" className="w-full justify-start" asChild>
          <Link href="/dashboard/principal/financial-analytics">
            <DollarSign className="mr-2 h-4 w-4" />
            Financial Analytics
          </Link>
        </Button>
        <Button variant="ghost" className="w-full justify-start" asChild>
          <Link href="/dashboard/principal/reports">
            <FileText className="mr-2 h-4 w-4" />
            Reports
          </Link>
        </Button>
        <Button variant="ghost" className="w-full justify-start" asChild>
          <Link href="/dashboard/principal/settings">
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </Link>
        </Button>
      </div>
    </nav>
  )
}

export default function FinancialAnalyticsPage() {
  return (
    <DashboardLayout sidebar={<PrincipalSidebar />}>
      <FinancialDashboard />
    </DashboardLayout>
  )
}
