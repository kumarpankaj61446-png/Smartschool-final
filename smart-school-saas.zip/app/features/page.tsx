import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { features } from "@/lib/sample-data"
import {
  QrCode,
  CreditCard,
  BookOpen,
  TrendingUp,
  MessageCircle,
  Brain,
  Bot,
  Trophy,
  Smartphone,
  CheckCircle,
  ArrowRight,
} from "lucide-react"

const iconMap = {
  QrCode,
  CreditCard,
  BookOpen,
  TrendingUp,
  MessageCircle,
  Brain,
  Bot,
  Trophy,
  Smartphone,
}

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <Badge variant="secondary" className="mb-4">
              Complete Feature Set
            </Badge>

            <h1 className="text-4xl lg:text-6xl font-bold text-balance bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 bg-clip-text text-transparent">
              Everything Your School Needs
            </h1>

            <p className="text-xl lg:text-2xl text-muted-foreground text-balance">
              Comprehensive tools designed to streamline every aspect of school management
            </p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = iconMap[feature.icon as keyof typeof iconMap]
              const isPremium = feature.title.includes("Premium")

              return (
                <Card
                  key={index}
                  className={`hover:shadow-lg transition-all duration-300 hover:-translate-y-1 ${isPremium ? "border-2 border-gradient-to-r from-yellow-400 to-orange-500" : ""}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                            isPremium
                              ? "bg-gradient-to-r from-yellow-100 to-orange-100 dark:from-yellow-900/20 dark:to-orange-900/20"
                              : "bg-blue-100 dark:bg-blue-900/20"
                          }`}
                        >
                          <IconComponent className={`w-6 h-6 ${isPremium ? "text-orange-600" : "text-blue-600"}`} />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{feature.title}</CardTitle>
                          {isPremium && (
                            <Badge
                              variant="secondary"
                              className="mt-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-white"
                            >
                              Premium
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base leading-relaxed">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Feature Categories */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Features by Category</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Organized solutions for every aspect of school management
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Administrative Features */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold flex items-center">
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center mr-3">
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                </div>
                Administrative Tools
              </h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Smart Attendance System</h4>
                    <p className="text-muted-foreground">QR code scanning for instant attendance tracking</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Fee Management</h4>
                    <p className="text-muted-foreground">Automated billing, payment processing, and reminders</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Student Progress Tracking</h4>
                    <p className="text-muted-foreground">Comprehensive analytics and reporting</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Educational Features */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold flex items-center">
                <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center mr-3">
                  <Brain className="w-5 h-5 text-purple-600" />
                </div>
                Educational Tools
              </h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">AI Lesson Planner</h4>
                    <p className="text-muted-foreground">Intelligent curriculum planning and resource suggestions</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">AI Study Buddy</h4>
                    <p className="text-muted-foreground">Personalized learning assistance for students</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Gamified Learning</h4>
                    <p className="text-muted-foreground">Engaging rewards system to motivate students</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="container text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Experience all these features with our 2-month free trial
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-6">
              Book a Demo
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 py-6 border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              Start Free Trial
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
