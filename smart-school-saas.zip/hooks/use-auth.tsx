"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import type { User } from "firebase/auth"
import { getFirebaseAuth, getFirebaseDb, type UserRole, type UserProfile } from "@/lib/firebase"
import { useRouter } from "next/navigation"
import { toast } from "@/hooks/use-toast"

interface AuthContextType {
  user: User | null
  userProfile: UserProfile | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, name: string, role: UserRole) => Promise<void>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    if (typeof window === "undefined") {
      setLoading(false)
      return
    }

    let unsubscribe: (() => void) | null = null

    const initializeAuth = async () => {
      try {
        const auth = await getFirebaseAuth()
        const db = await getFirebaseDb()
        const { onAuthStateChanged } = await import("firebase/auth")
        const { doc, getDoc } = await import("firebase/firestore")

        unsubscribe = onAuthStateChanged(auth, async (user) => {
          setUser(user)

          if (user) {
            try {
              const userDoc = await getDoc(doc(db, "users", user.uid))
              if (userDoc.exists()) {
                setUserProfile(userDoc.data() as UserProfile)
              }
            } catch (error) {
              console.error("Error fetching user profile:", error)
            }
          } else {
            setUserProfile(null)
          }

          setLoading(false)
        })
      } catch (error) {
        console.error("Error initializing Firebase Auth:", error)
        setLoading(false)
      }
    }

    initializeAuth()

    return () => {
      if (unsubscribe) {
        unsubscribe()
      }
    }
  }, [])

  const signIn = async (email: string, password: string) => {
    try {
      const auth = await getFirebaseAuth()
      const { signInWithEmailAndPassword } = await import("firebase/auth")

      await signInWithEmailAndPassword(auth, email, password)
      toast({
        title: "Welcome back!",
        description: "You have successfully signed in.",
      })
    } catch (error: any) {
      toast({
        title: "Sign in failed",
        description: error.message,
        variant: "destructive",
      })
      throw error
    }
  }

  const signUp = async (email: string, password: string, name: string, role: UserRole) => {
    try {
      const auth = await getFirebaseAuth()
      const db = await getFirebaseDb()
      const { createUserWithEmailAndPassword } = await import("firebase/auth")
      const { doc, setDoc } = await import("firebase/firestore")

      const { user } = await createUserWithEmailAndPassword(auth, email, password)

      const userProfile: UserProfile = {
        uid: user.uid,
        email: user.email!,
        role,
        name,
        createdAt: new Date(),
      }

      await setDoc(doc(db, "users", user.uid), userProfile)

      toast({
        title: "Account created!",
        description: "Your account has been created successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Sign up failed",
        description: error.message,
        variant: "destructive",
      })
      throw error
    }
  }

  const signOut = async () => {
    try {
      const auth = await getFirebaseAuth()
      const { signOut: firebaseSignOut } = await import("firebase/auth")

      await firebaseSignOut(auth)
      setUserProfile(null)
      router.push("/")
      toast({
        title: "Signed out",
        description: "You have been signed out successfully.",
      })
    } catch (error: any) {
      toast({
        title: "Sign out failed",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const resetPassword = async (email: string) => {
    try {
      const auth = await getFirebaseAuth()
      const { sendPasswordResetEmail } = await import("firebase/auth")

      await sendPasswordResetEmail(auth, email)
      toast({
        title: "Password reset email sent",
        description: "Check your email for password reset instructions.",
      })
    } catch (error: any) {
      toast({
        title: "Password reset failed",
        description: error.message,
        variant: "destructive",
      })
      throw error
    }
  }

  const value = {
    user,
    userProfile,
    loading,
    signIn,
    signUp,
    signOut,
    resetPassword,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
