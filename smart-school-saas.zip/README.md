# Smart School SaaS Platform

A comprehensive school management system built with Next.js 14, TypeScript, and Firebase.

## Features

- **Role-based Dashboards**: Separate interfaces for Principals, Teachers, Students, and Parents
- **Authentication**: Firebase-based user authentication with role management
- **Financial Analytics**: Comprehensive financial dashboard with revenue, expense, and collection tracking
- **Responsive Design**: Mobile-first design with dark/light mode support
- **Modern UI**: Built with shadcn/ui components and Tailwind CSS

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn
- Firebase project with Authentication and Firestore enabled

### Installation

1. Clone the repository:
\`\`\`bash
git clone <repository-url>
cd smart-school-saas
\`\`\`

2. Install dependencies:
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables:
Create a `.env.local` file in the root directory:
\`\`\`env
NEXT_PUBLIC_FIREBASE_API_KEY=your_firebase_api_key
\`\`\`

4. Copy the financial dashboard module:
\`\`\`bash
# Ensure the financial-dashboard module is in the correct location
cp -r modules/financial-dashboard /modules/financial-dashboard
\`\`\`

5. Run the development server:
\`\`\`bash
npm run dev
\`\`\`

6. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

\`\`\`
├── app/                    # Next.js app directory
│   ├── dashboard/         # Role-based dashboard pages
│   ├── login/            # Authentication pages
│   └── signup/
├── components/           # Reusable UI components
│   ├── ui/              # shadcn/ui components
│   └── dashboard-layout.tsx
├── hooks/               # Custom React hooks
├── lib/                 # Utility functions and configurations
├── modules/             # Feature modules
│   └── financial-dashboard/
└── public/              # Static assets
\`\`\`

## Deployment

### Vercel Deployment

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

### Build Instructions

\`\`\`bash
npm run build
npm start
\`\`\`

## Key Components

- **Authentication**: Firebase Auth with role-based access control
- **Dashboard Layout**: Responsive layout with sidebar navigation
- **Financial Analytics**: Comprehensive financial reporting and analytics
- **Charts**: Recharts integration for data visualization
- **Theme Support**: Light/dark mode with next-themes

## Environment Variables

- `NEXT_PUBLIC_FIREBASE_API_KEY`: Firebase API key for authentication

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

This project is licensed under the MIT License.
