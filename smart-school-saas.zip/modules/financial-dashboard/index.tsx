"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartCard } from "@/components/chart-card"
import { DataTable } from "@/components/data-table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DollarSign, TrendingUp, TrendingDown, CreditCard, AlertCircle, Download, Calendar } from "lucide-react"
import { sampleFinancialData } from "@/lib/sample-data"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts"

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"]

export function FinancialDashboard() {
  const currentMonth = sampleFinancialData[sampleFinancialData.length - 1]
  const previousMonth = sampleFinancialData[sampleFinancialData.length - 2]
  const revenueChange = ((currentMonth.revenue - previousMonth.revenue) / previousMonth.revenue) * 100

  const feeCollectionData = [
    { category: "Tuition Fees", amount: 45000, percentage: 65, status: "collected" },
    { category: "Lab Fees", amount: 8000, percentage: 80, status: "collected" },
    { category: "Library Fees", amount: 3000, percentage: 90, status: "collected" },
    { category: "Sports Fees", amount: 2000, percentage: 45, status: "pending" },
  ]

  const expenseBreakdown = [
    { name: "Salaries", value: 25000, color: "#3b82f6" },
    { name: "Utilities", value: 5000, color: "#10b981" },
    { name: "Maintenance", value: 3000, color: "#f59e0b" },
    { name: "Supplies", value: 4000, color: "#ef4444" },
    { name: "Other", value: 3000, color: "#8b5cf6" },
  ]

  const outstandingFees = [
    { student: "John Smith", grade: "10th", amount: 1200, daysOverdue: 15, contact: "john.smith@email.com" },
    { student: "Sarah Johnson", grade: "11th", amount: 800, daysOverdue: 8, contact: "sarah.j@email.com" },
    { student: "Mike Wilson", grade: "9th", amount: 1500, daysOverdue: 22, contact: "mike.w@email.com" },
    { student: "Emma Davis", grade: "12th", amount: 600, daysOverdue: 5, contact: "emma.d@email.com" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Financial Analytics</h1>
          <p className="text-muted-foreground">Comprehensive financial overview and insights</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
          <Select defaultValue="current-year">
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current-year">Current Year</SelectItem>
              <SelectItem value="last-year">Last Year</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="w-full sm:w-auto bg-transparent">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Financial Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl md:text-2xl font-bold">${currentMonth.revenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground flex items-center">
              {revenueChange > 0 ? (
                <TrendingUp className="w-3 h-3 mr-1 text-green-600" />
              ) : (
                <TrendingDown className="w-3 h-3 mr-1 text-red-600" />
              )}
              {Math.abs(revenueChange).toFixed(1)}% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl md:text-2xl font-bold">${currentMonth.expenses.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {((currentMonth.expenses / currentMonth.revenue) * 100).toFixed(1)}% of revenue
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl md:text-2xl font-bold text-green-600">${currentMonth.profit.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {((currentMonth.profit / currentMonth.revenue) * 100).toFixed(1)}% profit margin
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Fees</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl md:text-2xl font-bold text-orange-600">$4,100</div>
            <p className="text-xs text-muted-foreground">4 students with overdue payments</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="overview" className="text-xs md:text-sm">
            Overview
          </TabsTrigger>
          <TabsTrigger value="revenue" className="text-xs md:text-sm">
            Revenue
          </TabsTrigger>
          <TabsTrigger value="expenses" className="text-xs md:text-sm">
            Expenses
          </TabsTrigger>
          <TabsTrigger value="collections" className="text-xs md:text-sm">
            Collections
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <ChartCard title="Revenue vs Expenses" description="Monthly financial performance">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={sampleFinancialData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stackId="1"
                    stroke="#3b82f6"
                    fill="#3b82f6"
                    fillOpacity={0.6}
                  />
                  <Area
                    type="monotone"
                    dataKey="expenses"
                    stackId="2"
                    stroke="#ef4444"
                    fill="#ef4444"
                    fillOpacity={0.6}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Profit Trend" description="Monthly profit over time">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={sampleFinancialData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertCircle className="w-5 h-5 mr-2 text-orange-600" />
                Outstanding Fee Payments
              </CardTitle>
              <CardDescription>Students with overdue payments requiring attention</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <DataTable
                columns={[
                  { key: "student", label: "Student Name" },
                  { key: "grade", label: "Grade" },
                  {
                    key: "amount",
                    label: "Amount",
                    render: (value) => <span className="font-medium">${value}</span>,
                  },
                  {
                    key: "daysOverdue",
                    label: "Days Overdue",
                    render: (value) => (
                      <Badge variant={value > 15 ? "destructive" : value > 7 ? "secondary" : "outline"}>
                        {value} days
                      </Badge>
                    ),
                  },
                  { key: "contact", label: "Contact" },
                ]}
                data={outstandingFees}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <ChartCard title="Monthly Revenue" description="Revenue breakdown by month">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={sampleFinancialData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="revenue" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>

            <Card>
              <CardHeader>
                <CardTitle>Fee Collection Status</CardTitle>
                <CardDescription>Current month collection progress</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {feeCollectionData.map((fee, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">{fee.category}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-muted-foreground">${fee.amount.toLocaleString()}</span>
                        <Badge variant={fee.status === "collected" ? "default" : "secondary"}>{fee.percentage}%</Badge>
                      </div>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${fee.status === "collected" ? "bg-blue-600" : "bg-orange-500"}`}
                        style={{ width: `${fee.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <ChartCard title="Monthly Expenses" description="Expense trends over time">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={sampleFinancialData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="expenses" stroke="#ef4444" fill="#ef4444" fillOpacity={0.6} />
                </AreaChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Expense Breakdown" description="Current month expense distribution">
              <ResponsiveContainer width="100%" height={300}>
                <RechartsPieChart>
                  <Tooltip />
                  <RechartsPieChart data={expenseBreakdown} cx="50%" cy="50%" outerRadius={80} dataKey="value">
                    {expenseBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </RechartsPieChart>
                </RechartsPieChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Expense Categories</CardTitle>
              <CardDescription>Detailed breakdown of current month expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {expenseBreakdown.map((expense, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-4 h-4 rounded-full flex-shrink-0"
                        style={{ backgroundColor: expense.color }}
                      ></div>
                      <span className="font-medium">{expense.name}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">${expense.value.toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">
                        {((expense.value / currentMonth.expenses) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="collections" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Collection Rate</CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-xl md:text-2xl font-bold">92.3%</div>
                <p className="text-xs text-muted-foreground">This month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">On-time Payments</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-xl md:text-2xl font-bold">87.8%</div>
                <p className="text-xs text-muted-foreground">Within due date</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Average Days Late</CardTitle>
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-xl md:text-2xl font-bold">12.5</div>
                <p className="text-xs text-muted-foreground">For overdue payments</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Payment Methods</CardTitle>
              <CardDescription>How parents are paying fees</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Online Payment</span>
                    <span className="font-bold">65%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="h-2 rounded-full bg-blue-600" style={{ width: "65%" }}></div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Bank Transfer</span>
                    <span className="font-bold">25%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="h-2 rounded-full bg-green-600" style={{ width: "25%" }}></div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Cash</span>
                    <span className="font-bold">8%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="h-2 rounded-full bg-orange-600" style={{ width: "8%" }}></div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Check</span>
                    <span className="font-bold">2%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="h-2 rounded-full bg-purple-600" style={{ width: "2%" }}></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
