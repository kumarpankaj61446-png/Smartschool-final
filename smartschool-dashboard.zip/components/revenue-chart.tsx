"use client"

import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

const data = [
  { month: "Jan", revenue: 45000, target: 42000 },
  { month: "Feb", revenue: 47500, target: 45000 },
  { month: "Mar", revenue: 46200, target: 44000 },
  { month: "Apr", revenue: 48300, target: 46000 },
  { month: "May", revenue: 51200, target: 48000 },
  { month: "Jun", revenue: 49800, target: 47000 },
  { month: "Jul", revenue: 52100, target: 49000 },
  { month: "Aug", revenue: 54300, target: 51000 },
  { month: "Sep", revenue: 53800, target: 52000 },
  { month: "Oct", revenue: 55600, target: 53000 },
  { month: "Nov", revenue: 57200, target: 54000 },
  { month: "Dec", revenue: 58900, target: 55000 },
]

export function RevenueChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <XAxis dataKey="month" stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis
          stroke="#6b7280"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `$${value / 1000}k`}
        />
        <Tooltip
          content={({ active, payload, label }) => {
            if (active && payload && payload.length) {
              return (
                <div className="rounded-lg border bg-background p-2 shadow-sm">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex flex-col">
                      <span className="text-[0.70rem] uppercase text-muted-foreground">Revenue</span>
                      <span className="font-bold text-chart-1">${payload[0].value?.toLocaleString()}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[0.70rem] uppercase text-muted-foreground">Target</span>
                      <span className="font-bold text-chart-2">${payload[1].value?.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              )
            }
            return null
          }}
        />
        <Line
          type="monotone"
          dataKey="revenue"
          strokeWidth={2}
          stroke="var(--color-chart-1)"
          dot={{ fill: "var(--color-chart-1)", strokeWidth: 2, r: 4 }}
          activeDot={{ r: 6, stroke: "var(--color-chart-1)", strokeWidth: 2 }}
        />
        <Line
          type="monotone"
          dataKey="target"
          strokeWidth={2}
          stroke="var(--color-chart-2)"
          strokeDasharray="5 5"
          dot={{ fill: "var(--color-chart-2)", strokeWidth: 2, r: 4 }}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
