import { DollarSign, TrendingUp, TrendingDown, AlertCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const kpiData = [
  {
    title: "Total Revenue",
    value: "$233,200",
    change: "+12.5%",
    changeType: "positive" as const,
    icon: DollarSign,
    description: "vs last quarter",
  },
  {
    title: "Total Expenses",
    value: "$187,400",
    change: "+3.2%",
    changeType: "neutral" as const,
    icon: TrendingDown,
    description: "vs last quarter",
  },
  {
    title: "Net Profit",
    value: "$45,800",
    change: "+28.4%",
    changeType: "positive" as const,
    icon: TrendingUp,
    description: "vs last quarter",
  },
  {
    title: "Budget Utilization",
    value: "87.3%",
    change: "2 alerts",
    changeType: "warning" as const,
    icon: AlertCircle,
    description: "of allocated budget",
  },
]

export function KPICards() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {kpiData.map((kpi) => (
        <Card key={kpi.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{kpi.title}</CardTitle>
            <kpi.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpi.value}</div>
            <div className="flex items-center space-x-2 text-xs">
              <span
                className={`font-medium ${
                  kpi.changeType === "positive"
                    ? "text-chart-4"
                    : kpi.changeType === "warning"
                      ? "text-chart-3"
                      : "text-muted-foreground"
                }`}
              >
                {kpi.change}
              </span>
              <span className="text-muted-foreground">{kpi.description}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
