import { Progress } from "@/components/ui/progress"

const budgetData = [
  {
    category: "Salaries & Benefits",
    allocated: 350000,
    spent: 347600,
    percentage: 99.3,
  },
  {
    category: "Technology",
    allocated: 30000,
    spent: 28500,
    percentage: 95.0,
  },
  {
    category: "Utilities",
    allocated: 45000,
    spent: 38400,
    percentage: 85.3,
  },
  {
    category: "Supplies & Materials",
    allocated: 25000,
    spent: 18300,
    percentage: 73.2,
  },
  {
    category: "Maintenance & Repairs",
    allocated: 20000,
    spent: 15700,
    percentage: 78.5,
  },
]

export function BudgetOverview() {
  return (
    <div className="space-y-6">
      {budgetData.map((item) => (
        <div key={item.category} className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">{item.category}</span>
            <span className="text-muted-foreground">
              ${item.spent.toLocaleString()} / ${item.allocated.toLocaleString()}
            </span>
          </div>
          <Progress
            value={item.percentage}
            className="h-2"
            indicatorClassName={
              item.percentage > 95 ? "bg-destructive" : item.percentage > 85 ? "bg-chart-3" : "bg-chart-4"
            }
          />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{item.percentage}% utilized</span>
            <span>${(item.allocated - item.spent).toLocaleString()} remaining</span>
          </div>
        </div>
      ))}
    </div>
  )
}
