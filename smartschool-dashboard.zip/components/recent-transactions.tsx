import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const transactions = [
  {
    id: 1,
    date: "2024-01-15",
    description: "Q4 Tuition Collection",
    category: "Tuition Fees",
    type: "revenue",
    amount: 48300,
    status: "confirmed",
  },
  {
    id: 2,
    date: "2024-01-10",
    description: "Teacher Salaries - Q4",
    category: "Salaries & Benefits",
    type: "expense",
    amount: 88900,
    status: "approved",
  },
  {
    id: 3,
    date: "2024-01-08",
    description: "Computer Lab Upgrade",
    category: "Technology",
    type: "expense",
    amount: 15000,
    status: "approved",
  },
  {
    id: 4,
    date: "2024-01-05",
    description: "After School Program Fees",
    category: "After School Programs",
    type: "revenue",
    amount: 18000,
    status: "confirmed",
  },
  {
    id: 5,
    date: "2024-01-03",
    description: "Cafeteria Food Supplies",
    category: "Food Services",
    type: "expense",
    amount: 12000,
    status: "pending",
  },
]

export function RecentTransactions() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Date</TableHead>
          <TableHead>Description</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Type</TableHead>
          <TableHead className="text-right">Amount</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {transactions.map((transaction) => (
          <TableRow key={transaction.id}>
            <TableCell className="font-medium">{new Date(transaction.date).toLocaleDateString()}</TableCell>
            <TableCell>{transaction.description}</TableCell>
            <TableCell className="text-muted-foreground">{transaction.category}</TableCell>
            <TableCell>
              <Badge variant={transaction.type === "revenue" ? "default" : "secondary"}>{transaction.type}</Badge>
            </TableCell>
            <TableCell
              className={`text-right font-medium ${transaction.type === "revenue" ? "text-chart-4" : "text-chart-5"}`}
            >
              {transaction.type === "revenue" ? "+" : "-"}${transaction.amount.toLocaleString()}
            </TableCell>
            <TableCell>
              <Badge
                variant={
                  transaction.status === "confirmed" || transaction.status === "approved" ? "default" : "secondary"
                }
              >
                {transaction.status}
              </Badge>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
