"use client"

import { useState, useEffect } from "react"
import { Play, Clock, CheckCircle, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

interface CronJob {
  name: string
  schedule: string
  endpoint: string
  description: string
  enabled: boolean
  nextRun?: string
}

export function CronStatusPanel() {
  const [jobs, setJobs] = useState<CronJob[]>([])
  const [loading, setLoading] = useState(true)
  const [executing, setExecuting] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    fetchCronStatus()
  }, [])

  const fetchCronStatus = async () => {
    try {
      const response = await fetch("/api/cron/status")
      const data = await response.json()
      setJobs(data.jobs || [])
    } catch (error) {
      console.error("Error fetching cron status:", error)
      toast({
        title: "Error",
        description: "Failed to fetch cron job status",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const executeJob = async (jobName: string) => {
    setExecuting(jobName)
    try {
      const response = await fetch("/api/cron/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobName }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Success",
          description: `Cron job ${jobName} executed successfully`,
        })
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      console.error("Error executing cron job:", error)
      toast({
        title: "Error",
        description: `Failed to execute cron job ${jobName}`,
        variant: "destructive",
      })
    } finally {
      setExecuting(null)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Cron Jobs Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">Loading cron job status...</div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Clock className="h-5 w-5" />
          <span>Automated Tasks Status</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {jobs.map((job) => (
            <div key={job.name} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <h4 className="font-medium capitalize">{job.name.replace("-", " ")}</h4>
                  <Badge variant={job.enabled ? "default" : "secondary"}>{job.enabled ? "Enabled" : "Disabled"}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{job.description}</p>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <span>Schedule: {job.schedule}</span>
                  {job.nextRun && <span>Next run: {job.nextRun}</span>}
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {job.enabled ? (
                  <CheckCircle className="h-4 w-4 text-chart-4" />
                ) : (
                  <XCircle className="h-4 w-4 text-muted-foreground" />
                )}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => executeJob(job.name)}
                  disabled={executing === job.name || !job.enabled}
                >
                  {executing === job.name ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  ) : (
                    <Play className="h-4 w-4" />
                  )}
                  {executing === job.name ? "Running..." : "Run Now"}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
