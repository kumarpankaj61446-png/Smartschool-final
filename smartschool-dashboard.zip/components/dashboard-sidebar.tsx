"use client"

import { useState } from "react"
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  PieChart,
  AlertTriangle,
  Calendar,
  FileText,
  Settings,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const navigation = [
  { name: "Overview", href: "#", icon: BarChart3, current: true },
  { name: "Revenue", href: "#revenue", icon: TrendingUp, current: false },
  { name: "Expenses", href: "#expenses", icon: TrendingDown, current: false },
  { name: "Budget", href: "#budget", icon: PieChart, current: false },
  { name: "Alerts", href: "#alerts", icon: AlertTriangle, current: false },
  { name: "Reports", href: "#reports", icon: FileText, current: false },
  { name: "Calendar", href: "#calendar", icon: Calendar, current: false },
  { name: "Settings", href: "#settings", icon: Settings, current: false },
]

export function DashboardSidebar() {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div
      className={cn(
        "bg-sidebar border-r border-sidebar-border transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between p-4">
          {!collapsed && <h2 className="text-lg font-semibold text-sidebar-foreground">Navigation</h2>}
          <Button variant="ghost" size="icon" onClick={() => setCollapsed(!collapsed)} className="h-8 w-8">
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        <nav className="flex-1 space-y-1 px-2 pb-4">
          {navigation.map((item) => (
            <a
              key={item.name}
              href={item.href}
              className={cn(
                "group flex items-center rounded-md px-2 py-2 text-sm font-medium transition-colors",
                item.current
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
              )}
            >
              <item.icon className={cn("flex-shrink-0 h-5 w-5", collapsed ? "mr-0" : "mr-3")} aria-hidden="true" />
              {!collapsed && item.name}
            </a>
          ))}
        </nav>
      </div>
    </div>
  )
}
