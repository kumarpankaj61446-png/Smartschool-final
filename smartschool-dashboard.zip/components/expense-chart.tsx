"use client"

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts"

const data = [
  { name: "Salaries & Benefits", value: 347600, color: "var(--color-chart-1)" },
  { name: "Utilities", value: 38400, color: "var(--color-chart-2)" },
  { name: "Supplies & Materials", value: 18300, color: "var(--color-chart-3)" },
  { name: "Technology", value: 28500, color: "var(--color-chart-4)" },
  { name: "Other", value: 24200, color: "var(--color-chart-5)" },
]

export function ExpenseChart() {
  return (
    <div className="space-y-4">
      <ResponsiveContainer width="100%" height={200}>
        <PieChart>
          <Pie data={data} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={2} dataKey="value">
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="rounded-lg border bg-background p-2 shadow-sm">
                    <div className="flex flex-col">
                      <span className="text-[0.70rem] uppercase text-muted-foreground">{payload[0].name}</span>
                      <span className="font-bold">${payload[0].value?.toLocaleString()}</span>
                    </div>
                  </div>
                )
              }
              return null
            }}
          />
        </PieChart>
      </ResponsiveContainer>

      <div className="space-y-2">
        {data.map((item, index) => (
          <div key={index} className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-muted-foreground">{item.name}</span>
            </div>
            <span className="font-medium">${item.value.toLocaleString()}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
