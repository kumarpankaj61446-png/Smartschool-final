"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import { Mail, MessageSquare, Send } from "lucide-react"

export function NotificationTestPanel() {
  const [alertType, setAlertType] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const alertTypes = [
    { value: "budget_warning", label: "Budget Warning", description: "Test budget limit exceeded alert" },
    { value: "revenue_milestone", label: "Revenue Milestone", description: "Test revenue target achieved alert" },
    { value: "expense_anomaly", label: "Expense Anomaly", description: "Test unusual expense pattern alert" },
    { value: "budget_approval", label: "Budget Approval", description: "Test budget update notification" },
  ]

  const handleSendTest = async () => {
    if (!alertType) {
      toast.error("Please select an alert type")
      return
    }

    if (!email && !phone) {
      toast.error("Please provide either email or phone number")
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/test-notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: alertType,
          email: email || undefined,
          phone: phone || undefined,
        }),
      })

      const result = await response.json()

      if (response.ok) {
        toast.success(`Test notification sent successfully!`)
        console.log("[v0] Test notification result:", result)
      } else {
        toast.error(`Failed to send test: ${result.error}`)
        console.error("[v0] Test notification error:", result.error)
      }
    } catch (error) {
      toast.error("Network error occurred")
      console.error("[v0] Test notification network error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Send className="h-5 w-5" />
          Test Notifications
        </CardTitle>
        <CardDescription>Send test notifications to verify SendGrid and Twilio integration</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="alert-type">Alert Type</Label>
          <Select value={alertType} onValueChange={setAlertType}>
            <SelectTrigger>
              <SelectValue placeholder="Select alert type to test" />
            </SelectTrigger>
            <SelectContent>
              {alertTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  <div>
                    <div className="font-medium">{type.label}</div>
                    <div className="text-sm text-muted-foreground">{type.description}</div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              Email (Optional)
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="test@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Phone (Optional)
            </Label>
            <Input
              id="phone"
              type="tel"
              placeholder="+1234567890"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
        </div>

        <Button onClick={handleSendTest} disabled={isLoading || !alertType} className="w-full">
          {isLoading ? "Sending..." : "Send Test Notification"}
        </Button>

        <div className="text-sm text-muted-foreground">
          <p>
            <strong>Note:</strong> Email notifications will be sent via SendGrid, SMS notifications via Twilio.
          </p>
          <p>High/medium severity alerts will trigger both email and SMS if both are provided.</p>
        </div>
      </CardContent>
    </Card>
  )
}
