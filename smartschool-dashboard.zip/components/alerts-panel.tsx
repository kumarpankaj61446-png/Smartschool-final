import { AlertTriangle, CheckCircle, Info, XCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const alerts = [
  {
    id: 1,
    type: "warning",
    title: "Technology Budget Alert",
    message: "Technology category has exceeded 95% of allocated budget",
    severity: "high" as const,
    time: "2 hours ago",
    isRead: false,
  },
  {
    id: 2,
    type: "success",
    title: "Revenue Target Met",
    message: "Q4 tuition collection has exceeded target by 8%",
    severity: "low" as const,
    time: "1 day ago",
    isRead: false,
  },
  {
    id: 3,
    type: "info",
    title: "Budget Allocation Updated",
    message: "Maintenance budget increased by $5,000 for emergency repairs",
    severity: "low" as const,
    time: "2 days ago",
    isRead: true,
  },
  {
    id: 4,
    type: "error",
    title: "Unusual Expense Detected",
    message: "Utilities expense 25% higher than previous month",
    severity: "medium" as const,
    time: "3 days ago",
    isRead: true,
  },
]

const getAlertIcon = (type: string) => {
  switch (type) {
    case "warning":
      return AlertTriangle
    case "success":
      return CheckCircle
    case "error":
      return XCircle
    default:
      return Info
  }
}

const getAlertColor = (severity: string) => {
  switch (severity) {
    case "high":
      return "destructive"
    case "medium":
      return "secondary"
    default:
      return "outline"
  }
}

export function AlertsPanel() {
  return (
    <div className="space-y-4">
      {alerts.map((alert) => {
        const Icon = getAlertIcon(alert.type)
        return (
          <div
            key={alert.id}
            className={`p-3 rounded-lg border ${alert.isRead ? "bg-muted/50" : "bg-card"} transition-colors`}
          >
            <div className="flex items-start space-x-3">
              <Icon
                className={`h-4 w-4 mt-0.5 ${
                  alert.type === "warning"
                    ? "text-chart-3"
                    : alert.type === "success"
                      ? "text-chart-4"
                      : alert.type === "error"
                        ? "text-destructive"
                        : "text-muted-foreground"
                }`}
              />
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className={`text-sm font-medium ${alert.isRead ? "text-muted-foreground" : "text-foreground"}`}>
                    {alert.title}
                  </h4>
                  <Badge variant={getAlertColor(alert.severity) as any} className="text-xs">
                    {alert.severity}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">{alert.message}</p>
                <p className="text-xs text-muted-foreground">{alert.time}</p>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
