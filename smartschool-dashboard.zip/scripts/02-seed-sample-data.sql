-- Seed sample data for SmartSchool financial analytics

-- Insert sample school
INSERT INTO schools (name, address, phone, email, principal_name) VALUES
('Greenwood Elementary', '123 Oak Street, Springfield, IL 62701', '(555) 123-4567', 'admin@greenwood.edu', 'Dr. Sarah Johnson');

-- Insert revenue categories
INSERT INTO revenue_categories (name, description) VALUES
('Tuition Fees', 'Student tuition and enrollment fees'),
('Government Grants', 'Federal and state education grants'),
('Donations', 'Private donations and fundraising'),
('Events & Activities', 'Revenue from school events and activities'),
('Book Sales', 'Textbook and material sales'),
('After School Programs', 'Revenue from extended day programs');

-- Insert expense categories
INSERT INTO expense_categories (name, description) VALUES
('Salaries & Benefits', 'Teacher and staff compensation'),
('Utilities', 'Electricity, water, gas, internet'),
('Supplies & Materials', 'Classroom supplies and educational materials'),
('Maintenance & Repairs', 'Building and equipment maintenance'),
('Technology', 'Computer equipment and software'),
('Transportation', 'School bus and vehicle expenses'),
('Food Services', 'Cafeteria and meal program costs'),
('Insurance', 'Property and liability insurance');

-- Insert sample revenue records (last 12 months)
INSERT INTO revenue_records (school_id, category_id, amount, description, transaction_date, payment_method, status) VALUES
(1, 1, 45000.00, 'Q1 Tuition Collection', '2024-01-15', 'Bank Transfer', 'confirmed'),
(1, 1, 47500.00, 'Q2 Tuition Collection', '2024-04-15', 'Bank Transfer', 'confirmed'),
(1, 1, 46200.00, 'Q3 Tuition Collection', '2024-07-15', 'Bank Transfer', 'confirmed'),
(1, 1, 48300.00, 'Q4 Tuition Collection', '2024-10-15', 'Bank Transfer', 'confirmed'),
(1, 2, 25000.00, 'Federal Education Grant', '2024-02-01', 'Government Transfer', 'confirmed'),
(1, 2, 15000.00, 'State Technology Grant', '2024-06-01', 'Government Transfer', 'confirmed'),
(1, 3, 8500.00, 'Annual Fundraising Gala', '2024-03-20', 'Mixed', 'confirmed'),
(1, 3, 3200.00, 'Parent Donations', '2024-05-10', 'Online', 'confirmed'),
(1, 4, 2800.00, 'Science Fair Entry Fees', '2024-04-25', 'Cash', 'confirmed'),
(1, 4, 1500.00, 'Sports Tournament', '2024-09-15', 'Card', 'confirmed'),
(1, 5, 12000.00, 'Textbook Sales', '2024-08-20', 'Mixed', 'confirmed'),
(1, 6, 18000.00, 'After School Program Fees', '2024-09-01', 'Bank Transfer', 'confirmed');

-- Insert sample expense records
INSERT INTO expense_records (school_id, category_id, amount, description, transaction_date, vendor_name, status) VALUES
(1, 1, 85000.00, 'Teacher Salaries - Q1', '2024-01-31', 'Payroll Services Inc', 'approved'),
(1, 1, 87500.00, 'Teacher Salaries - Q2', '2024-04-30', 'Payroll Services Inc', 'approved'),
(1, 1, 86200.00, 'Teacher Salaries - Q3', '2024-07-31', 'Payroll Services Inc', 'approved'),
(1, 1, 88900.00, 'Teacher Salaries - Q4', '2024-10-31', 'Payroll Services Inc', 'approved'),
(1, 2, 3500.00, 'Electricity Bill', '2024-01-15', 'City Electric Company', 'approved'),
(1, 2, 4200.00, 'Electricity Bill', '2024-02-15', 'City Electric Company', 'approved'),
(1, 2, 3800.00, 'Electricity Bill', '2024-03-15', 'City Electric Company', 'approved'),
(1, 2, 2900.00, 'Water & Sewer', '2024-01-20', 'Municipal Water Dept', 'approved'),
(1, 3, 5500.00, 'Classroom Supplies', '2024-08-15', 'Educational Supply Co', 'approved'),
(1, 3, 2800.00, 'Art Supplies', '2024-09-10', 'Creative Materials Inc', 'approved'),
(1, 4, 8500.00, 'HVAC Maintenance', '2024-06-15', 'Climate Control Services', 'approved'),
(1, 4, 1200.00, 'Plumbing Repairs', '2024-07-20', 'Quick Fix Plumbing', 'approved'),
(1, 5, 15000.00, 'Computer Lab Upgrade', '2024-05-01', 'Tech Solutions LLC', 'approved'),
(1, 5, 3500.00, 'Software Licenses', '2024-09-01', 'EduSoft Systems', 'approved'),
(1, 6, 4500.00, 'Bus Fuel & Maintenance', '2024-08-01', 'School Transport Co', 'approved'),
(1, 7, 12000.00, 'Cafeteria Food Supplies', '2024-09-01', 'Fresh Foods Distributor', 'approved'),
(1, 8, 6500.00, 'Annual Insurance Premium', '2024-01-01', 'Education Insurance Group', 'approved');

-- Insert budget allocations for current year
INSERT INTO budget_allocations (school_id, category_id, allocated_amount, spent_amount, budget_year) VALUES
(1, 1, 350000.00, 347600.00, 2024),
(1, 2, 45000.00, 38400.00, 2024),
(1, 3, 25000.00, 18300.00, 2024),
(1, 4, 20000.00, 15700.00, 2024),
(1, 5, 30000.00, 28500.00, 2024),
(1, 6, 15000.00, 12500.00, 2024),
(1, 7, 40000.00, 36000.00, 2024),
(1, 8, 10000.00, 9500.00, 2024);

-- Insert sample financial alerts
INSERT INTO financial_alerts (school_id, alert_type, title, message, severity, is_read) VALUES
(1, 'budget_warning', 'Technology Budget Alert', 'Technology category has exceeded 95% of allocated budget', 'high', FALSE),
(1, 'revenue_milestone', 'Quarterly Revenue Target Met', 'Q4 tuition collection has exceeded target by 8%', 'low', FALSE),
(1, 'expense_anomaly', 'Unusual Expense Detected', 'Utilities expense 25% higher than previous month', 'medium', TRUE),
(1, 'budget_approval', 'Budget Allocation Updated', 'Maintenance budget increased by $5,000 for emergency repairs', 'low', TRUE);
