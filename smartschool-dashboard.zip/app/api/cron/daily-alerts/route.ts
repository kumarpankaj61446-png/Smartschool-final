import { NextResponse } from "next/server"
import { AlertTriggers } from "@/lib/alert-triggers"
import { sql } from "@/lib/database"

// Daily cron job for financial alerts monitoring
export async function GET() {
  try {
    console.log("[CRON] Starting daily financial alerts check...")

    // Get all active schools
    const schools = await sql`
      SELECT id, name 
      FROM schools 
      ORDER BY id
    `

    let totalAlertsGenerated = 0

    // Run alert checks for each school
    for (const school of schools) {
      console.log(`[CRON] Checking alerts for school: ${school.name} (ID: ${school.id})`)

      try {
        await AlertTriggers.runAllChecks(Number(school.id))
        console.log(`[CRON] Completed alert checks for school: ${school.name}`)
      } catch (error) {
        console.error(`[CRON] Error checking alerts for school ${school.name}:`, error)
      }
    }

    // Get count of alerts generated today
    const today = new Date().toISOString().split("T")[0]
    const todayAlerts = await sql`
      SELECT COUNT(*) as count
      FROM financial_alerts 
      WHERE DATE(created_at) = ${today}
    `

    totalAlertsGenerated = Number(todayAlerts[0].count)

    console.log(`[CRON] Daily alerts check completed. Generated ${totalAlertsGenerated} alerts.`)

    return NextResponse.json({
      success: true,
      message: "Daily alerts check completed",
      schoolsChecked: schools.length,
      alertsGenerated: totalAlertsGenerated,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[CRON] Error in daily alerts check:", error)
    return NextResponse.json(
      {
        error: "Failed to complete daily alerts check",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

// Verify cron authentication (in production, you'd use a secret token)
function verifyCronAuth(request: Request): boolean {
  const authHeader = request.headers.get("authorization")
  const cronSecret = process.env.CRON_SECRET || "dev-secret"

  return authHeader === `Bearer ${cronSecret}`
}

// POST method for manual trigger with authentication
export async function POST(request: Request) {
  if (!verifyCronAuth(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  return GET()
}
