import { NextResponse } from "next/server"
import { executeCronJob } from "@/lib/cron-scheduler"

// Manual execution of cron jobs
export async function POST(request: Request) {
  try {
    const { jobName } = await request.json()

    if (!jobName) {
      return NextResponse.json({ error: "Job name is required" }, { status: 400 })
    }

    const success = await executeCronJob(jobName)

    if (success) {
      return NextResponse.json({
        success: true,
        message: `Cron job ${jobName} executed successfully`,
      })
    } else {
      return NextResponse.json({ error: `Failed to execute cron job ${jobName}` }, { status: 500 })
    }
  } catch (error) {
    console.error("Error executing cron job:", error)
    return NextResponse.json({ error: "Failed to execute cron job" }, { status: 500 })
  }
}
