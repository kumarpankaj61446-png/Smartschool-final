import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

// Monthly budget synchronization - updates spent amounts based on actual expenses
export async function GET() {
  try {
    console.log("[CRON] Starting monthly budget synchronization...")

    const currentYear = new Date().getFullYear()

    // Get all schools
    const schools = await sql`
      SELECT id, name FROM schools ORDER BY id
    `

    let totalUpdated = 0

    for (const school of schools) {
      const schoolId = Number(school.id)

      // Calculate actual spending per category for current year
      const actualSpending = await sql`
        SELECT 
          er.category_id,
          SUM(er.amount) as total_spent
        FROM expense_records er
        WHERE er.school_id = ${schoolId}
        AND EXTRACT(YEAR FROM er.transaction_date) = ${currentYear}
        AND er.status = 'approved'
        GROUP BY er.category_id
      `

      // Update budget allocations with actual spending
      for (const spending of actualSpending) {
        const categoryId = Number(spending.category_id)
        const totalSpent = Number(spending.total_spent)

        await sql`
          UPDATE budget_allocations 
          SET 
            spent_amount = ${totalSpent},
            updated_at = NOW()
          WHERE school_id = ${schoolId} 
          AND category_id = ${categoryId}
          AND budget_year = ${currentYear}
        `

        totalUpdated++
      }

      console.log(`[CRON] Updated budget data for school: ${school.name}`)
    }

    console.log(`[CRON] Budget synchronization completed. Updated ${totalUpdated} budget entries.`)

    return NextResponse.json({
      success: true,
      message: "Budget synchronization completed",
      schoolsProcessed: schools.length,
      budgetEntriesUpdated: totalUpdated,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[CRON] Error in budget synchronization:", error)
    return NextResponse.json(
      {
        error: "Failed to complete budget synchronization",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
