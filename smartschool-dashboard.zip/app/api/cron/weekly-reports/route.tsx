import { NextResponse } from "next/server"
import { sql } from "@/lib/database"
import { NotificationService } from "@/lib/notifications"

// Weekly financial summary report
export async function GET() {
  try {
    console.log("[CRON] Starting weekly financial reports...")

    const schools = await sql`
      SELECT id, name, principal_name, email 
      FROM schools 
      ORDER BY id
    `

    for (const school of schools) {
      await generateWeeklyReport(Number(school.id), school)
    }

    console.log("[CRON] Weekly reports completed")

    return NextResponse.json({
      success: true,
      message: "Weekly reports sent",
      schoolsProcessed: schools.length,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[CRON] Error in weekly reports:", error)
    return NextResponse.json(
      {
        error: "Failed to generate weekly reports",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

async function generateWeeklyReport(schoolId: number, school: any) {
  try {
    const currentDate = new Date()
    const weekAgo = new Date(currentDate.getTime() - 7 * 24 * 60 * 60 * 1000)
    const currentYear = currentDate.getFullYear()

    // Get weekly financial summary
    const weeklyRevenue = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM revenue_records 
      WHERE school_id = ${schoolId}
      AND transaction_date >= ${weekAgo.toISOString().split("T")[0]}
      AND transaction_date <= ${currentDate.toISOString().split("T")[0]}
    `

    const weeklyExpenses = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM expense_records 
      WHERE school_id = ${schoolId}
      AND transaction_date >= ${weekAgo.toISOString().split("T")[0]}
      AND transaction_date <= ${currentDate.toISOString().split("T")[0]}
    `

    const yearToDateRevenue = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM revenue_records 
      WHERE school_id = ${schoolId}
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
    `

    const yearToDateExpenses = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM expense_records 
      WHERE school_id = ${schoolId}
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
    `

    const budgetUtilization = await sql`
      SELECT 
        SUM(allocated_amount) as total_allocated,
        SUM(spent_amount) as total_spent,
        ROUND(AVG(spent_amount / allocated_amount * 100)::numeric, 1) as avg_utilization
      FROM budget_allocations 
      WHERE school_id = ${schoolId} AND budget_year = ${currentYear}
    `

    const weeklyAlerts = await sql`
      SELECT COUNT(*) as count
      FROM financial_alerts 
      WHERE school_id = ${schoolId}
      AND created_at >= ${weekAgo.toISOString()}
    `

    // Prepare report data
    const reportData = {
      school: school.name,
      principal: school.principal_name,
      weekPeriod: `${weekAgo.toLocaleDateString()} - ${currentDate.toLocaleDateString()}`,
      weeklyRevenue: Number(weeklyRevenue[0].total),
      weeklyExpenses: Number(weeklyExpenses[0].total),
      weeklyProfit: Number(weeklyRevenue[0].total) - Number(weeklyExpenses[0].total),
      ytdRevenue: Number(yearToDateRevenue[0].total),
      ytdExpenses: Number(yearToDateExpenses[0].total),
      ytdProfit: Number(yearToDateRevenue[0].total) - Number(yearToDateExpenses[0].total),
      budgetUtilization: Number(budgetUtilization[0]?.avg_utilization || 0),
      alertsCount: Number(weeklyAlerts[0].count),
    }

    // Generate and send weekly report email
    const emailHtml = generateWeeklyReportEmail(reportData)

    await NotificationService.sendEmail(school.email, `Weekly Financial Report - ${school.name}`, emailHtml)

    console.log(`[CRON] Weekly report sent to ${school.name}`)
  } catch (error) {
    console.error(`[CRON] Error generating report for school ${school.name}:`, error)
  }
}

function generateWeeklyReportEmail(data: any): string {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: #1f2937; color: white; padding: 20px; text-align: center;">
        <h1 style="margin: 0;">Weekly Financial Report</h1>
        <p style="margin: 5px 0 0 0; opacity: 0.8;">${data.school}</p>
      </div>
      
      <div style="padding: 20px; background: #f9fafb;">
        <p>Dear ${data.principal},</p>
        <p>Here's your weekly financial summary for the period ${data.weekPeriod}:</p>
        
        <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h2 style="color: #1f2937; margin-top: 0;">Weekly Summary</h2>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div>
              <h3 style="color: #10b981; margin: 0;">Revenue</h3>
              <p style="font-size: 24px; font-weight: bold; margin: 5px 0;">$${data.weeklyRevenue.toLocaleString()}</p>
            </div>
            <div>
              <h3 style="color: #be123c; margin: 0;">Expenses</h3>
              <p style="font-size: 24px; font-weight: bold; margin: 5px 0;">$${data.weeklyExpenses.toLocaleString()}</p>
            </div>
          </div>
          <div style="border-top: 1px solid #e5e7eb; padding-top: 15px; margin-top: 15px;">
            <h3 style="color: ${data.weeklyProfit >= 0 ? "#10b981" : "#be123c"}; margin: 0;">Net Result</h3>
            <p style="font-size: 24px; font-weight: bold; margin: 5px 0; color: ${data.weeklyProfit >= 0 ? "#10b981" : "#be123c"};">
              ${data.weeklyProfit >= 0 ? "+" : ""}$${data.weeklyProfit.toLocaleString()}
            </p>
          </div>
        </div>
        
        <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h2 style="color: #1f2937; margin-top: 0;">Year-to-Date Performance</h2>
          <ul style="list-style: none; padding: 0;">
            <li style="margin: 10px 0;"><strong>Total Revenue:</strong> $${data.ytdRevenue.toLocaleString()}</li>
            <li style="margin: 10px 0;"><strong>Total Expenses:</strong> $${data.ytdExpenses.toLocaleString()}</li>
            <li style="margin: 10px 0;"><strong>Net Profit:</strong> <span style="color: ${data.ytdProfit >= 0 ? "#10b981" : "#be123c"};">${data.ytdProfit >= 0 ? "+" : ""}$${data.ytdProfit.toLocaleString()}</span></li>
            <li style="margin: 10px 0;"><strong>Budget Utilization:</strong> ${data.budgetUtilization}%</li>
          </ul>
        </div>
        
        ${
          data.alertsCount > 0
            ? `
        <div style="background: #fef3c7; border: 1px solid #f59e0b; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #92400e; margin-top: 0;">⚠️ Alerts This Week</h3>
          <p style="color: #92400e; margin: 0;">You received ${data.alertsCount} financial alert${data.alertsCount > 1 ? "s" : ""} this week. Please review your dashboard for details.</p>
        </div>
        `
            : ""
        }
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" 
             style="background: #8b5cf6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
            View Full Dashboard
          </a>
        </div>
        
        <p style="color: #6b7280; font-size: 14px;">
          This report is automatically generated every week. If you have any questions about your financial data, 
          please contact your SmartSchool support team.
        </p>
      </div>
      
      <div style="background: #1f2937; color: #9ca3af; padding: 15px; text-align: center; font-size: 12px;">
        SmartSchool Financial Analytics | Weekly Report | ${new Date().toLocaleDateString()}
      </div>
    </div>
  `
}
