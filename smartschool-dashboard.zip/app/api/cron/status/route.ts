import { NextResponse } from "next/server"
import { getCronJobStatus } from "@/lib/cron-scheduler"

// Get status of all cron jobs
export async function GET() {
  try {
    const cronStatus = getCronJobStatus()

    return NextResponse.json({
      success: true,
      jobs: cronStatus,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error getting cron status:", error)
    return NextResponse.json({ error: "Failed to get cron status" }, { status: 500 })
  }
}
