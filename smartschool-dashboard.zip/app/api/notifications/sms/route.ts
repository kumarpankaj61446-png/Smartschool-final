import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { to, message } = await request.json()

    // Real Twilio implementation
    const twilio = require("twilio")
    const client = twilio("ACc38114a932f17104225b611f8b564307", "2f7a86308c0bf9ff65f40660e146e04c")

    const result = await client.messages.create({
      body: message,
      from: "+19835517008", // Your Twilio phone number
      to: to,
    })

    console.log(`[TWILIO] SMS sent to: ${to}`)
    console.log(`[TWILIO] Message: ${message}`)

    return NextResponse.json({
      success: true,
      sid: result.sid,
      message: "SMS sent successfully",
    })
  } catch (error) {
    console.error("Twilio SMS error:", error)
    return NextResponse.json({ error: "Failed to send SMS" }, { status: 500 })
  }
}
