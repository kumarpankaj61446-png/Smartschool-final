import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { to, subject, html } = await request.json()

    // Real SendGrid implementation
    const sgMail = require("@sendgrid/mail")
    sgMail.setApiKey("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")

    const msg = {
      to,
      from: "noreply@smartschool.com", // You may need to verify this email with SendGrid
      subject,
      html,
    }

    const result = await sgMail.send(msg)

    console.log(`[SENDGRID] Email sent to: ${to}`)
    console.log(`[SENDGRID] Subject: ${subject}`)

    return NextResponse.json({
      success: true,
      messageId: result[0].headers["x-message-id"],
      message: "Email sent successfully",
    })
  } catch (error) {
    console.error("SendGrid email error:", error)
    return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
  }
}
