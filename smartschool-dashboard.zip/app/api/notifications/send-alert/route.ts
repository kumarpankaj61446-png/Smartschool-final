import { NextResponse } from "next/server"
import { sql } from "@/lib/database"
import { NotificationService, type AlertNotification } from "@/lib/notifications"

export async function POST(request: Request) {
  try {
    const alertData: AlertNotification = await request.json()

    // Get school and principal contact information
    const schoolInfo = await sql`
      SELECT name, principal_name, email, phone
      FROM schools 
      WHERE id = ${alertData.schoolId}
    `

    if (schoolInfo.length === 0) {
      return NextResponse.json({ error: "School not found" }, { status: 404 })
    }

    const school = schoolInfo[0]

    // Store alert in database
    await sql`
      INSERT INTO financial_alerts (
        school_id, alert_type, title, message, severity, is_read
      ) VALUES (
        ${alertData.schoolId}, ${alertData.type}, ${alertData.title}, 
        ${alertData.message}, ${alertData.severity}, false
      )
    `

    // Send notification to principal
    await NotificationService.sendAlert(alertData, {
      email: school.email,
      phone: school.phone,
    })

    return NextResponse.json({
      success: true,
      message: "Alert sent and stored successfully",
    })
  } catch (error) {
    console.error("Error sending alert:", error)
    return NextResponse.json({ error: "Failed to send alert" }, { status: 500 })
  }
}
