import { NextResponse } from "next/server"
import { AlertTriggers } from "@/lib/alert-triggers"

// Manual trigger for alert checks (useful for testing)
export async function POST(request: Request) {
  try {
    const { schoolId } = await request.json()

    if (!schoolId) {
      return NextResponse.json({ error: "School ID is required" }, { status: 400 })
    }

    await AlertTriggers.runAllChecks(schoolId)

    return NextResponse.json({
      success: true,
      message: "Alert checks completed successfully",
    })
  } catch (error) {
    console.error("Error running alert checks:", error)
    return NextResponse.json({ error: "Failed to run alert checks" }, { status: 500 })
  }
}
