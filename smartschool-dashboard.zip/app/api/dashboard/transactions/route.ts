import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    // Get recent transactions (both revenue and expenses)
    const revenueTransactions = await sql`
      SELECT 
        rr.id,
        rr.transaction_date as date,
        rr.description,
        rc.name as category,
        'revenue' as type,
        rr.amount,
        rr.status,
        rr.created_at
      FROM revenue_records rr
      JOIN revenue_categories rc ON rr.category_id = rc.id
      WHERE rr.school_id = 1
    `

    const expenseTransactions = await sql`
      SELECT 
        er.id,
        er.transaction_date as date,
        er.description,
        ec.name as category,
        'expense' as type,
        er.amount,
        er.status,
        er.created_at
      FROM expense_records er
      JOIN expense_categories ec ON er.category_id = ec.id
      WHERE er.school_id = 1
    `

    // Combine and sort transactions
    const allTransactions = [
      ...revenueTransactions.map((t) => ({
        id: `r-${t.id}`,
        date: t.date,
        description: t.description,
        category: t.category,
        type: t.type,
        amount: Number(t.amount),
        status: t.status,
        createdAt: t.created_at,
      })),
      ...expenseTransactions.map((t) => ({
        id: `e-${t.id}`,
        date: t.date,
        description: t.description,
        category: t.category,
        type: t.type,
        amount: Number(t.amount),
        status: t.status,
        createdAt: t.created_at,
      })),
    ]

    // Sort by date (most recent first)
    allTransactions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    // Apply pagination
    const paginatedTransactions = allTransactions.slice(offset, offset + limit)

    return NextResponse.json({
      transactions: paginatedTransactions,
      total: allTransactions.length,
      hasMore: offset + limit < allTransactions.length,
    })
  } catch (error) {
    console.error("Error fetching transactions:", error)
    return NextResponse.json({ error: "Failed to fetch transactions" }, { status: 500 })
  }
}
