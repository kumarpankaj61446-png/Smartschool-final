import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

export async function GET() {
  try {
    const currentYear = new Date().getFullYear()

    // Get expenses by category for current year
    const expensesByCategory = await sql`
      SELECT 
        ec.name as category,
        SUM(er.amount) as total
      FROM expense_records er
      JOIN expense_categories ec ON er.category_id = ec.id
      WHERE er.school_id = 1 
      AND EXTRACT(YEAR FROM er.transaction_date) = ${currentYear}
      GROUP BY ec.name
      ORDER BY total DESC
    `

    // Get monthly expense trends
    const monthlyExpenses = await sql`
      SELECT 
        EXTRACT(MONTH FROM transaction_date) as month,
        SUM(amount) as expenses
      FROM expense_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
      GROUP BY EXTRACT(MONTH FROM transaction_date)
      ORDER BY month
    `

    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const monthlyData = months.map((month, index) => {
      const monthNum = index + 1
      const expenseData = monthlyExpenses.find((e) => Number(e.month) === monthNum)
      return {
        month,
        expenses: expenseData ? Number(expenseData.expenses) : 0,
      }
    })

    // Format data for pie chart
    const chartData = expensesByCategory.map((item) => ({
      name: item.category,
      value: Number(item.total),
    }))

    return NextResponse.json({
      chartData,
      monthlyData,
      totalExpenses: chartData.reduce((sum, item) => sum + item.value, 0),
    })
  } catch (error) {
    console.error("Error fetching expense data:", error)
    return NextResponse.json({ error: "Failed to fetch expense data" }, { status: 500 })
  }
}
