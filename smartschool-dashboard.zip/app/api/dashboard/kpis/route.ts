import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

export async function GET() {
  try {
    // Get current year and quarter
    const currentYear = new Date().getFullYear()
    const currentQuarter = Math.floor((new Date().getMonth() + 3) / 3)
    const lastQuarter = currentQuarter === 1 ? 4 : currentQuarter - 1
    const lastQuarterYear = currentQuarter === 1 ? currentYear - 1 : currentYear

    // Calculate total revenue for current and last quarter
    const currentQuarterRevenue = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM revenue_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
      AND EXTRACT(QUARTER FROM transaction_date) = ${currentQuarter}
    `

    const lastQuarterRevenue = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM revenue_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${lastQuarterYear}
      AND EXTRACT(QUARTER FROM transaction_date) = ${lastQuarter}
    `

    // Calculate total expenses for current and last quarter
    const currentQuarterExpenses = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM expense_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
      AND EXTRACT(QUARTER FROM transaction_date) = ${currentQuarter}
    `

    const lastQuarterExpenses = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM expense_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${lastQuarterYear}
      AND EXTRACT(QUARTER FROM transaction_date) = ${lastQuarter}
    `

    // Calculate budget utilization
    const budgetData = await sql`
      SELECT 
        SUM(allocated_amount) as total_allocated,
        SUM(spent_amount) as total_spent
      FROM budget_allocations 
      WHERE school_id = 1 AND budget_year = ${currentYear}
    `

    // Count unread alerts
    const alertsCount = await sql`
      SELECT COUNT(*) as count
      FROM financial_alerts 
      WHERE school_id = 1 AND is_read = false
    `

    const currentRevenue = Number(currentQuarterRevenue[0].total)
    const lastRevenue = Number(lastQuarterRevenue[0].total)
    const currentExpenses = Number(currentQuarterExpenses[0].total)
    const lastExpenses = Number(lastQuarterExpenses[0].total)
    const totalAllocated = Number(budgetData[0].total_allocated)
    const totalSpent = Number(budgetData[0].total_spent)

    const revenueChange = lastRevenue > 0 ? ((currentRevenue - lastRevenue) / lastRevenue) * 100 : 0
    const expenseChange = lastExpenses > 0 ? ((currentExpenses - lastExpenses) / lastExpenses) * 100 : 0
    const netProfit = currentRevenue - currentExpenses
    const lastNetProfit = lastRevenue - lastExpenses
    const profitChange = lastNetProfit > 0 ? ((netProfit - lastNetProfit) / lastNetProfit) * 100 : 0
    const budgetUtilization = totalAllocated > 0 ? (totalSpent / totalAllocated) * 100 : 0

    return NextResponse.json({
      totalRevenue: {
        value: currentRevenue,
        change: revenueChange,
        changeType: revenueChange > 0 ? "positive" : revenueChange < 0 ? "negative" : "neutral",
      },
      totalExpenses: {
        value: currentExpenses,
        change: expenseChange,
        changeType: expenseChange > 0 ? "negative" : expenseChange < 0 ? "positive" : "neutral",
      },
      netProfit: {
        value: netProfit,
        change: profitChange,
        changeType: profitChange > 0 ? "positive" : profitChange < 0 ? "negative" : "neutral",
      },
      budgetUtilization: {
        value: budgetUtilization,
        alertsCount: Number(alertsCount[0].count),
        changeType: budgetUtilization > 90 ? "warning" : "neutral",
      },
    })
  } catch (error) {
    console.error("Error fetching KPIs:", error)
    return NextResponse.json({ error: "Failed to fetch KPIs" }, { status: 500 })
  }
}
