import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

export async function GET() {
  try {
    // Get all alerts for the school
    const alerts = await sql`
      SELECT 
        id,
        alert_type,
        title,
        message,
        severity,
        is_read,
        created_at
      FROM financial_alerts 
      WHERE school_id = 1
      ORDER BY created_at DESC
      LIMIT 10
    `

    const formattedAlerts = alerts.map((alert) => ({
      id: alert.id,
      type: alert.alert_type,
      title: alert.title,
      message: alert.message,
      severity: alert.severity,
      isRead: alert.is_read,
      time: formatTimeAgo(new Date(alert.created_at)),
    }))

    return NextResponse.json({
      alerts: formattedAlerts,
      unreadCount: formattedAlerts.filter((alert) => !alert.isRead).length,
    })
  } catch (error) {
    console.error("Error fetching alerts:", error)
    return NextResponse.json({ error: "Failed to fetch alerts" }, { status: 500 })
  }
}

export async function PATCH(request: Request) {
  try {
    const { alertId, isRead } = await request.json()

    await sql`
      UPDATE financial_alerts 
      SET is_read = ${isRead}
      WHERE id = ${alertId} AND school_id = 1
    `

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating alert:", error)
    return NextResponse.json({ error: "Failed to update alert" }, { status: 500 })
  }
}

function formatTimeAgo(date: Date): string {
  const now = new Date()
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (diffInSeconds < 60) return "Just now"
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`
  return `${Math.floor(diffInSeconds / 86400)} days ago`
}
