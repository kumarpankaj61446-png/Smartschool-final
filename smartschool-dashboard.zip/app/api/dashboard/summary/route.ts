import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

export async function GET() {
  try {
    const currentYear = new Date().getFullYear()

    // Get school information
    const schoolInfo = await sql`
      SELECT name, principal_name, email, phone
      FROM schools 
      WHERE id = 1
    `

    // Get financial summary
    const totalRevenue = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM revenue_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
    `

    const totalExpenses = await sql`
      SELECT COALESCE(SUM(amount), 0) as total
      FROM expense_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
    `

    const budgetInfo = await sql`
      SELECT 
        SUM(allocated_amount) as total_allocated,
        SUM(spent_amount) as total_spent
      FROM budget_allocations 
      WHERE school_id = 1 AND budget_year = ${currentYear}
    `

    const alertsCount = await sql`
      SELECT 
        COUNT(*) as total_alerts,
        COUNT(CASE WHEN is_read = false THEN 1 END) as unread_alerts
      FROM financial_alerts 
      WHERE school_id = 1
    `

    const revenue = Number(totalRevenue[0].total)
    const expenses = Number(totalExpenses[0].total)
    const allocated = Number(budgetInfo[0].total_allocated)
    const spent = Number(budgetInfo[0].total_spent)

    return NextResponse.json({
      school: {
        name: schoolInfo[0].name,
        principal: schoolInfo[0].principal_name,
        email: schoolInfo[0].email,
        phone: schoolInfo[0].phone,
      },
      financial: {
        totalRevenue: revenue,
        totalExpenses: expenses,
        netProfit: revenue - expenses,
        budgetAllocated: allocated,
        budgetSpent: spent,
        budgetUtilization: allocated > 0 ? (spent / allocated) * 100 : 0,
      },
      alerts: {
        total: Number(alertsCount[0].total_alerts),
        unread: Number(alertsCount[0].unread_alerts),
      },
      year: currentYear,
    })
  } catch (error) {
    console.error("Error fetching dashboard summary:", error)
    return NextResponse.json({ error: "Failed to fetch dashboard summary" }, { status: 500 })
  }
}
