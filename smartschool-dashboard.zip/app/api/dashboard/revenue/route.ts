import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

export async function GET() {
  try {
    // Get monthly revenue data for the current year
    const currentYear = new Date().getFullYear()

    const monthlyRevenue = await sql`
      SELECT 
        EXTRACT(MONTH FROM transaction_date) as month,
        SUM(amount) as revenue
      FROM revenue_records 
      WHERE school_id = 1 
      AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
      GROUP BY EXTRACT(MONTH FROM transaction_date)
      ORDER BY month
    `

    // Get revenue by category
    const revenueByCategory = await sql`
      SELECT 
        rc.name as category,
        SUM(rr.amount) as total
      FROM revenue_records rr
      JOIN revenue_categories rc ON rr.category_id = rc.id
      WHERE rr.school_id = 1 
      AND EXTRACT(YEAR FROM rr.transaction_date) = ${currentYear}
      GROUP BY rc.name
      ORDER BY total DESC
    `

    // Create monthly data with targets (assuming 10% growth target)
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const monthlyData = months.map((month, index) => {
      const monthNum = index + 1
      const revenueData = monthlyRevenue.find((r) => Number(r.month) === monthNum)
      const revenue = revenueData ? Number(revenueData.revenue) : 0
      const target = revenue > 0 ? revenue * 0.9 : 45000 + index * 1000 // Base target with growth

      return {
        month,
        revenue,
        target: Math.round(target),
      }
    })

    return NextResponse.json({
      monthlyData,
      categoryData: revenueByCategory.map((item) => ({
        category: item.category,
        total: Number(item.total),
      })),
    })
  } catch (error) {
    console.error("Error fetching revenue data:", error)
    return NextResponse.json({ error: "Failed to fetch revenue data" }, { status: 500 })
  }
}
