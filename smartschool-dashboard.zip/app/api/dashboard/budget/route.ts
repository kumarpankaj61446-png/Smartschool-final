import { NextResponse } from "next/server"
import { sql } from "@/lib/database"

export async function GET() {
  try {
    const currentYear = new Date().getFullYear()

    // Get budget allocations with spent amounts
    const budgetData = await sql`
      SELECT 
        ec.name as category,
        ba.allocated_amount,
        ba.spent_amount,
        ROUND((ba.spent_amount / ba.allocated_amount * 100)::numeric, 1) as percentage
      FROM budget_allocations ba
      JOIN expense_categories ec ON ba.category_id = ec.id
      WHERE ba.school_id = 1 
      AND ba.budget_year = ${currentYear}
      ORDER BY percentage DESC
    `

    const formattedData = budgetData.map((item) => ({
      category: item.category,
      allocated: Number(item.allocated_amount),
      spent: Number(item.spent_amount),
      percentage: Number(item.percentage),
      remaining: Number(item.allocated_amount) - Number(item.spent_amount),
    }))

    return NextResponse.json({
      budgetData: formattedData,
      totalAllocated: formattedData.reduce((sum, item) => sum + item.allocated, 0),
      totalSpent: formattedData.reduce((sum, item) => sum + item.spent, 0),
    })
  } catch (error) {
    console.error("Error fetching budget data:", error)
    return NextResponse.json({ error: "Failed to fetch budget data" }, { status: 500 })
  }
}
