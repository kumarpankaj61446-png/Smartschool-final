import { NextResponse } from "next/server"
import { NotificationService } from "@/lib/notifications"

export async function POST(request: Request) {
  try {
    const { type, email, phone } = await request.json()

    if (!type || (!email && !phone)) {
      return NextResponse.json({ error: "Missing required fields: type and (email or phone)" }, { status: 400 })
    }

    // Test data for different alert types
    const testData = {
      budget_warning: {
        category: "Technology",
        percentage: 85,
        allocated: 50000,
        spent: 42500,
        remaining: 7500,
      },
      revenue_milestone: {
        title: "Monthly Target Achieved",
        message: "Congratulations! You've exceeded your monthly revenue target.",
        currentRevenue: 125000,
        target: 100000,
        exceededBy: 25,
      },
      expense_anomaly: {
        category: "Utilities",
        message: "Unusual increase in utility expenses detected.",
        currentAmount: 8500,
        previousAmount: 6000,
        increasePercentage: 42,
      },
      budget_approval: {
        category: "Sports Equipment",
        message: "Budget allocation has been updated for sports equipment.",
        previousBudget: 15000,
        newBudget: 20000,
        change: 5000,
      },
    }

    const alertData = testData[type as keyof typeof testData]
    if (!alertData) {
      return NextResponse.json(
        { error: "Invalid alert type. Use: budget_warning, revenue_milestone, expense_anomaly, or budget_approval" },
        { status: 400 },
      )
    }

    // Create test alert notification
    const alert = {
      type: type as "budget_warning" | "revenue_milestone" | "expense_anomaly" | "budget_approval",
      title: `Test ${type.replace("_", " ")} Alert`,
      message: `This is a test notification for ${type.replace("_", " ")}`,
      severity: "medium" as const,
      schoolId: 1,
      data: alertData,
    }

    // Send the test notification
    await NotificationService.sendAlert(alert, { email, phone })

    return NextResponse.json({
      success: true,
      message: `Test ${type} notification sent successfully`,
      recipients: { email: email || null, phone: phone || null },
    })
  } catch (error) {
    console.error("Test notification error:", error)
    return NextResponse.json({ error: "Failed to send test notification" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({
    message: "SmartSchool Notification Test Endpoint",
    usage: {
      method: "POST",
      body: {
        type: "budget_warning | revenue_milestone | expense_anomaly | budget_approval",
        email: "recipient@example.com (optional)",
        phone: "+1234567890 (optional, for SMS)",
      },
    },
    examples: [
      {
        type: "budget_warning",
        email: "principal@school.edu",
        phone: "+1234567890",
      },
      {
        type: "revenue_milestone",
        email: "admin@school.edu",
      },
    ],
  })
}
