// API client utilities for dashboard data fetching

export interface KPIData {
  totalRevenue: {
    value: number
    change: number
    changeType: "positive" | "negative" | "neutral"
  }
  totalExpenses: {
    value: number
    change: number
    changeType: "positive" | "negative" | "neutral"
  }
  netProfit: {
    value: number
    change: number
    changeType: "positive" | "negative" | "neutral"
  }
  budgetUtilization: {
    value: number
    alertsCount: number
    changeType: "warning" | "neutral"
  }
}

export interface RevenueData {
  monthlyData: Array<{
    month: string
    revenue: number
    target: number
  }>
  categoryData: Array<{
    category: string
    total: number
  }>
}

export interface ExpenseData {
  chartData: Array<{
    name: string
    value: number
  }>
  monthlyData: Array<{
    month: string
    expenses: number
  }>
  totalExpenses: number
}

export interface BudgetData {
  budgetData: Array<{
    category: string
    allocated: number
    spent: number
    percentage: number
    remaining: number
  }>
  totalAllocated: number
  totalSpent: number
}

export interface AlertData {
  alerts: Array<{
    id: number
    type: string
    title: string
    message: string
    severity: "low" | "medium" | "high"
    isRead: boolean
    time: string
  }>
  unreadCount: number
}

export interface TransactionData {
  transactions: Array<{
    id: string
    date: string
    description: string
    category: string
    type: "revenue" | "expense"
    amount: number
    status: string
  }>
  total: number
  hasMore: boolean
}

// API client functions
export const apiClient = {
  async getKPIs(): Promise<KPIData> {
    const response = await fetch("/api/dashboard/kpis")
    if (!response.ok) throw new Error("Failed to fetch KPIs")
    return response.json()
  },

  async getRevenueData(): Promise<RevenueData> {
    const response = await fetch("/api/dashboard/revenue")
    if (!response.ok) throw new Error("Failed to fetch revenue data")
    return response.json()
  },

  async getExpenseData(): Promise<ExpenseData> {
    const response = await fetch("/api/dashboard/expenses")
    if (!response.ok) throw new Error("Failed to fetch expense data")
    return response.json()
  },

  async getBudgetData(): Promise<BudgetData> {
    const response = await fetch("/api/dashboard/budget")
    if (!response.ok) throw new Error("Failed to fetch budget data")
    return response.json()
  },

  async getAlerts(): Promise<AlertData> {
    const response = await fetch("/api/dashboard/alerts")
    if (!response.ok) throw new Error("Failed to fetch alerts")
    return response.json()
  },

  async getTransactions(limit = 10, offset = 0): Promise<TransactionData> {
    const response = await fetch(`/api/dashboard/transactions?limit=${limit}&offset=${offset}`)
    if (!response.ok) throw new Error("Failed to fetch transactions")
    return response.json()
  },

  async markAlertAsRead(alertId: number, isRead: boolean): Promise<void> {
    const response = await fetch("/api/dashboard/alerts", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ alertId, isRead }),
    })
    if (!response.ok) throw new Error("Failed to update alert")
  },
}

// Utility functions for formatting
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export const formatPercentage = (value: number): string => {
  return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`
}

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}
