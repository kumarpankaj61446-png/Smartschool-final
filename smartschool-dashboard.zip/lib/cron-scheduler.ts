// Cron job scheduler configuration and utilities

export interface CronJob {
  name: string
  schedule: string
  endpoint: string
  description: string
  enabled: boolean
}

// Cron job definitions
export const cronJobs: CronJob[] = [
  {
    name: "daily-alerts",
    schedule: "0 9 * * *", // Every day at 9 AM
    endpoint: "/api/cron/daily-alerts",
    description: "Check for budget alerts, revenue milestones, and expense anomalies",
    enabled: true,
  },
  {
    name: "weekly-reports",
    schedule: "0 8 * * 1", // Every Monday at 8 AM
    endpoint: "/api/cron/weekly-reports",
    description: "Generate and send weekly financial summary reports",
    enabled: true,
  },
  {
    name: "budget-sync",
    schedule: "0 2 1 * *", // First day of every month at 2 AM
    endpoint: "/api/cron/budget-sync",
    description: "Synchronize budget allocations with actual spending",
    enabled: true,
  },
]

// Utility to parse cron expressions for display
export function parseCronSchedule(schedule: string): string {
  const parts = schedule.split(" ")
  if (parts.length !== 5) return schedule

  const [minute, hour, day, month, weekday] = parts

  // Simple cron parser for common patterns
  if (schedule === "0 9 * * *") return "Daily at 9:00 AM"
  if (schedule === "0 8 * * 1") return "Weekly on Monday at 8:00 AM"
  if (schedule === "0 2 1 * *") return "Monthly on 1st at 2:00 AM"

  return schedule
}

// Manual cron job execution
export async function executeCronJob(jobName: string): Promise<boolean> {
  try {
    const job = cronJobs.find((j) => j.name === jobName)
    if (!job) {
      console.error(`Cron job not found: ${jobName}`)
      return false
    }

    console.log(`[CRON] Manually executing job: ${jobName}`)

    const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}${job.endpoint}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.CRON_SECRET || "dev-secret"}`,
        "Content-Type": "application/json",
      },
    })

    if (response.ok) {
      console.log(`[CRON] Job ${jobName} executed successfully`)
      return true
    } else {
      console.error(`[CRON] Job ${jobName} failed with status: ${response.status}`)
      return false
    }
  } catch (error) {
    console.error(`[CRON] Error executing job ${jobName}:`, error)
    return false
  }
}

// Get cron job status
export function getCronJobStatus(): Array<CronJob & { nextRun?: string }> {
  return cronJobs.map((job) => ({
    ...job,
    nextRun: getNextRunTime(job.schedule),
  }))
}

// Calculate next run time (simplified)
function getNextRunTime(schedule: string): string {
  // This is a simplified implementation
  // In production, you'd use a proper cron parser library
  const now = new Date()

  if (schedule === "0 9 * * *") {
    const next = new Date(now)
    next.setHours(9, 0, 0, 0)
    if (next <= now) {
      next.setDate(next.getDate() + 1)
    }
    return next.toLocaleString()
  }

  if (schedule === "0 8 * * 1") {
    const next = new Date(now)
    const daysUntilMonday = (1 + 7 - next.getDay()) % 7 || 7
    next.setDate(next.getDate() + daysUntilMonday)
    next.setHours(8, 0, 0, 0)
    return next.toLocaleString()
  }

  if (schedule === "0 2 1 * *") {
    const next = new Date(now.getFullYear(), now.getMonth() + 1, 1, 2, 0, 0)
    return next.toLocaleString()
  }

  return "Unknown"
}
