import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export { sql }

// Database types
export interface School {
  id: number
  name: string
  address?: string
  phone?: string
  email?: string
  principal_name?: string
  created_at: string
  updated_at: string
}

export interface RevenueCategory {
  id: number
  name: string
  description?: string
  created_at: string
}

export interface ExpenseCategory {
  id: number
  name: string
  description?: string
  created_at: string
}

export interface RevenueRecord {
  id: number
  school_id: number
  category_id: number
  amount: number
  description?: string
  transaction_date: string
  payment_method?: string
  status: string
  created_at: string
  updated_at: string
  category_name?: string
}

export interface ExpenseRecord {
  id: number
  school_id: number
  category_id: number
  amount: number
  description?: string
  transaction_date: string
  vendor_name?: string
  status: string
  created_at: string
  updated_at: string
  category_name?: string
}

export interface BudgetAllocation {
  id: number
  school_id: number
  category_id: number
  allocated_amount: number
  spent_amount: number
  budget_year: number
  created_at: string
  updated_at: string
  category_name?: string
}

export interface FinancialAlert {
  id: number
  school_id: number
  alert_type: string
  title: string
  message: string
  severity: "low" | "medium" | "high"
  is_read: boolean
  created_at: string
}
