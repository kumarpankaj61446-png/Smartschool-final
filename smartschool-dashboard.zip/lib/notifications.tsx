// Notification system for SmartSchool financial alerts

export interface NotificationConfig {
  email?: {
    to: string
    subject: string
    html: string
  }
  sms?: {
    to: string
    message: string
  }
}

export interface AlertNotification {
  type: "budget_warning" | "revenue_milestone" | "expense_anomaly" | "budget_approval"
  title: string
  message: string
  severity: "low" | "medium" | "high"
  schoolId: number
  data?: Record<string, any>
}

// Email templates for different alert types
export const emailTemplates = {
  budget_warning: (data: any) => ({
    subject: `🚨 Budget Alert: ${data.category} Exceeding Limit`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #be123c; color: white; padding: 20px; text-align: center;">
          <h1 style="margin: 0;">Budget Warning Alert</h1>
        </div>
        <div style="padding: 20px; background: #f9fafb;">
          <h2 style="color: #1f2937;">Budget Limit Exceeded</h2>
          <p>The <strong>${data.category}</strong> budget category has exceeded <strong>${data.percentage}%</strong> of its allocated budget.</p>
          
          <div style="background: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #1f2937;">Budget Details:</h3>
            <ul style="list-style: none; padding: 0;">
              <li><strong>Category:</strong> ${data.category}</li>
              <li><strong>Allocated:</strong> $${data.allocated?.toLocaleString()}</li>
              <li><strong>Spent:</strong> $${data.spent?.toLocaleString()}</li>
              <li><strong>Remaining:</strong> $${data.remaining?.toLocaleString()}</li>
              <li><strong>Utilization:</strong> ${data.percentage}%</li>
            </ul>
          </div>
          
          <p style="color: #6b7280;">Please review your spending in this category and consider budget adjustments if necessary.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" 
               style="background: #8b5cf6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              View Dashboard
            </a>
          </div>
        </div>
        <div style="background: #1f2937; color: #9ca3af; padding: 15px; text-align: center; font-size: 12px;">
          SmartSchool Financial Analytics | This is an automated alert
        </div>
      </div>
    `,
  }),

  revenue_milestone: (data: any) => ({
    subject: `🎉 Revenue Milestone: ${data.title}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #10b981; color: white; padding: 20px; text-align: center;">
          <h1 style="margin: 0;">Revenue Milestone Achieved!</h1>
        </div>
        <div style="padding: 20px; background: #f9fafb;">
          <h2 style="color: #1f2937;">Congratulations!</h2>
          <p>${data.message}</p>
          
          <div style="background: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #1f2937;">Revenue Summary:</h3>
            <ul style="list-style: none; padding: 0;">
              <li><strong>Current Revenue:</strong> $${data.currentRevenue?.toLocaleString()}</li>
              <li><strong>Target:</strong> $${data.target?.toLocaleString()}</li>
              <li><strong>Exceeded by:</strong> ${data.exceededBy}%</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" 
               style="background: #8b5cf6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              View Dashboard
            </a>
          </div>
        </div>
        <div style="background: #1f2937; color: #9ca3af; padding: 15px; text-align: center; font-size: 12px;">
          SmartSchool Financial Analytics | This is an automated alert
        </div>
      </div>
    `,
  }),

  expense_anomaly: (data: any) => ({
    subject: `⚠️ Expense Anomaly Detected: ${data.category}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #f97316; color: white; padding: 20px; text-align: center;">
          <h1 style="margin: 0;">Expense Anomaly Alert</h1>
        </div>
        <div style="padding: 20px; background: #f9fafb;">
          <h2 style="color: #1f2937;">Unusual Expense Pattern Detected</h2>
          <p>${data.message}</p>
          
          <div style="background: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #1f2937;">Expense Details:</h3>
            <ul style="list-style: none; padding: 0;">
              <li><strong>Category:</strong> ${data.category}</li>
              <li><strong>Current Month:</strong> $${data.currentAmount?.toLocaleString()}</li>
              <li><strong>Previous Month:</strong> $${data.previousAmount?.toLocaleString()}</li>
              <li><strong>Increase:</strong> ${data.increasePercentage}%</li>
            </ul>
          </div>
          
          <p style="color: #6b7280;">Please review recent transactions in this category to identify the cause of this increase.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" 
               style="background: #8b5cf6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              View Dashboard
            </a>
          </div>
        </div>
        <div style="background: #1f2937; color: #9ca3af; padding: 15px; text-align: center; font-size: 12px;">
          SmartSchool Financial Analytics | This is an automated alert
        </div>
      </div>
    `,
  }),

  budget_approval: (data: any) => ({
    subject: `✅ Budget Update: ${data.category}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #4f46e5; color: white; padding: 20px; text-align: center;">
          <h1 style="margin: 0;">Budget Update Notification</h1>
        </div>
        <div style="padding: 20px; background: #f9fafb;">
          <h2 style="color: #1f2937;">Budget Allocation Updated</h2>
          <p>${data.message}</p>
          
          <div style="background: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #1f2937;">Update Details:</h3>
            <ul style="list-style: none; padding: 0;">
              <li><strong>Category:</strong> ${data.category}</li>
              <li><strong>Previous Budget:</strong> $${data.previousBudget?.toLocaleString()}</li>
              <li><strong>New Budget:</strong> $${data.newBudget?.toLocaleString()}</li>
              <li><strong>Change:</strong> $${data.change?.toLocaleString()}</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" 
               style="background: #8b5cf6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              View Dashboard
            </a>
          </div>
        </div>
        <div style="background: #1f2937; color: #9ca3af; padding: 15px; text-align: center; font-size: 12px;">
          SmartSchool Financial Analytics | This is an automated alert
        </div>
      </div>
    `,
  }),
}

// SMS templates for different alert types
export const smsTemplates = {
  budget_warning: (data: any) =>
    `🚨 SmartSchool Alert: ${data.category} budget has exceeded ${data.percentage}% of allocation. Spent: $${data.spent?.toLocaleString()}/${data.allocated?.toLocaleString()}. Review dashboard: ${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,

  revenue_milestone: (data: any) =>
    `🎉 SmartSchool: Revenue milestone achieved! Current: $${data.currentRevenue?.toLocaleString()}, exceeded target by ${data.exceededBy}%. View details: ${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,

  expense_anomaly: (data: any) =>
    `⚠️ SmartSchool Alert: ${data.category} expenses increased ${data.increasePercentage}% from last month. Current: $${data.currentAmount?.toLocaleString()}. Check dashboard: ${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,

  budget_approval: (data: any) =>
    `✅ SmartSchool: ${data.category} budget updated. New allocation: $${data.newBudget?.toLocaleString()} (${data.change >= 0 ? "+" : ""}$${data.change?.toLocaleString()}). View: ${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
}

// Main notification service
export class NotificationService {
  // Send email notification using SendGrid
  static async sendEmail(to: string, subject: string, html: string): Promise<boolean> {
    try {
      console.log(`[EMAIL] Sending to: ${to}, Subject: ${subject}`)

      const response = await fetch("/api/notifications/email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to, subject, html }),
      })

      const result = await response.json()

      if (response.ok) {
        console.log(`[EMAIL] Successfully sent: ${result.messageId}`)
        return true
      } else {
        console.error(`[EMAIL] Failed: ${result.error}`)
        return false
      }
    } catch (error) {
      console.error("Failed to send email:", error)
      return false
    }
  }

  // Send SMS notification using Twilio
  static async sendSMS(to: string, message: string): Promise<boolean> {
    try {
      console.log(`[SMS] Sending to: ${to}, Message: ${message.substring(0, 50)}...`)

      const response = await fetch("/api/notifications/sms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to, message }),
      })

      const result = await response.json()

      if (response.ok) {
        console.log(`[SMS] Successfully sent: ${result.sid}`)
        return true
      } else {
        console.error(`[SMS] Failed: ${result.error}`)
        return false
      }
    } catch (error) {
      console.error("Failed to send SMS:", error)
      return false
    }
  }

  // Send notification based on alert type
  static async sendAlert(alert: AlertNotification, recipients: { email?: string; phone?: string }): Promise<void> {
    try {
      const emailTemplate = emailTemplates[alert.type]
      const smsTemplate = smsTemplates[alert.type]

      if (!emailTemplate || !smsTemplate) {
        throw new Error(`Unknown alert type: ${alert.type}`)
      }

      const emailContent = emailTemplate(alert.data)
      const smsContent = smsTemplate(alert.data)

      // Send email if recipient email is provided
      if (recipients.email) {
        await this.sendEmail(recipients.email, emailContent.subject, emailContent.html)
      }

      // Send SMS for high severity alerts or if phone is provided
      if (recipients.phone && (alert.severity === "high" || alert.severity === "medium")) {
        await this.sendSMS(recipients.phone, smsContent)
      }

      console.log(`[NOTIFICATION] Alert sent: ${alert.type} - ${alert.title}`)
    } catch (error) {
      console.error("Failed to send alert notification:", error)
    }
  }
}
