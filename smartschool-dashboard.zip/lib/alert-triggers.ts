// Alert trigger system for financial monitoring

import { sql } from "@/lib/database"
import type { AlertNotification } from "@/lib/notifications"

export class AlertTriggers {
  // Check budget utilization and trigger alerts if thresholds are exceeded
  static async checkBudgetAlerts(schoolId: number): Promise<void> {
    try {
      const currentYear = new Date().getFullYear()

      // Get budget allocations with current spending
      const budgetData = await sql`
        SELECT 
          ba.id,
          ba.category_id,
          ec.name as category_name,
          ba.allocated_amount,
          ba.spent_amount,
          ROUND((ba.spent_amount / ba.allocated_amount * 100)::numeric, 1) as percentage
        FROM budget_allocations ba
        JOIN expense_categories ec ON ba.category_id = ec.id
        WHERE ba.school_id = ${schoolId} 
        AND ba.budget_year = ${currentYear}
        AND ba.spent_amount / ba.allocated_amount >= 0.90
      `

      for (const budget of budgetData) {
        const percentage = Number(budget.percentage)
        const allocated = Number(budget.allocated_amount)
        const spent = Number(budget.spent_amount)
        const remaining = allocated - spent

        if (percentage >= 95) {
          // High severity alert for 95%+ utilization
          const alert: AlertNotification = {
            type: "budget_warning",
            title: `${budget.category_name} Budget Critical`,
            message: `${budget.category_name} has exceeded 95% of allocated budget`,
            severity: "high",
            schoolId,
            data: {
              category: budget.category_name,
              allocated,
              spent,
              remaining,
              percentage,
            },
          }

          await this.sendAlert(alert)
        } else if (percentage >= 90) {
          // Medium severity alert for 90%+ utilization
          const alert: AlertNotification = {
            type: "budget_warning",
            title: `${budget.category_name} Budget Warning`,
            message: `${budget.category_name} has exceeded 90% of allocated budget`,
            severity: "medium",
            schoolId,
            data: {
              category: budget.category_name,
              allocated,
              spent,
              remaining,
              percentage,
            },
          }

          await this.sendAlert(alert)
        }
      }
    } catch (error) {
      console.error("Error checking budget alerts:", error)
    }
  }

  // Check for revenue milestones and achievements
  static async checkRevenueAlerts(schoolId: number): Promise<void> {
    try {
      const currentYear = new Date().getFullYear()
      const currentQuarter = Math.floor((new Date().getMonth() + 3) / 3)

      // Get current quarter revenue
      const currentRevenue = await sql`
        SELECT COALESCE(SUM(amount), 0) as total
        FROM revenue_records 
        WHERE school_id = ${schoolId}
        AND EXTRACT(YEAR FROM transaction_date) = ${currentYear}
        AND EXTRACT(QUARTER FROM transaction_date) = ${currentQuarter}
      `

      // Get target (assuming 10% growth from previous year same quarter)
      const previousYearRevenue = await sql`
        SELECT COALESCE(SUM(amount), 0) as total
        FROM revenue_records 
        WHERE school_id = ${schoolId}
        AND EXTRACT(YEAR FROM transaction_date) = ${currentYear - 1}
        AND EXTRACT(QUARTER FROM transaction_date) = ${currentQuarter}
      `

      const current = Number(currentRevenue[0].total)
      const previous = Number(previousYearRevenue[0].total)
      const target = previous * 1.1 // 10% growth target

      if (current > target && target > 0) {
        const exceededBy = ((current - target) / target) * 100

        const alert: AlertNotification = {
          type: "revenue_milestone",
          title: "Quarterly Revenue Target Exceeded",
          message: `Q${currentQuarter} revenue has exceeded target by ${exceededBy.toFixed(1)}%`,
          severity: "low",
          schoolId,
          data: {
            currentRevenue: current,
            target,
            exceededBy: exceededBy.toFixed(1),
            quarter: currentQuarter,
          },
        }

        await this.sendAlert(alert)
      }
    } catch (error) {
      console.error("Error checking revenue alerts:", error)
    }
  }

  // Check for expense anomalies (unusual spending patterns)
  static async checkExpenseAlerts(schoolId: number): Promise<void> {
    try {
      const currentMonth = new Date().getMonth() + 1
      const currentYear = new Date().getFullYear()
      const previousMonth = currentMonth === 1 ? 12 : currentMonth - 1
      const previousYear = currentMonth === 1 ? currentYear - 1 : currentYear

      // Get expense categories with significant month-over-month increases
      const expenseComparison = await sql`
        WITH current_month AS (
          SELECT 
            er.category_id,
            ec.name as category_name,
            SUM(er.amount) as current_amount
          FROM expense_records er
          JOIN expense_categories ec ON er.category_id = ec.id
          WHERE er.school_id = ${schoolId}
          AND EXTRACT(MONTH FROM er.transaction_date) = ${currentMonth}
          AND EXTRACT(YEAR FROM er.transaction_date) = ${currentYear}
          GROUP BY er.category_id, ec.name
        ),
        previous_month AS (
          SELECT 
            er.category_id,
            SUM(er.amount) as previous_amount
          FROM expense_records er
          WHERE er.school_id = ${schoolId}
          AND EXTRACT(MONTH FROM er.transaction_date) = ${previousMonth}
          AND EXTRACT(YEAR FROM er.transaction_date) = ${previousYear}
          GROUP BY er.category_id
        )
        SELECT 
          cm.category_name,
          cm.current_amount,
          COALESCE(pm.previous_amount, 0) as previous_amount,
          CASE 
            WHEN pm.previous_amount > 0 THEN 
              ROUND(((cm.current_amount - pm.previous_amount) / pm.previous_amount * 100)::numeric, 1)
            ELSE 100
          END as increase_percentage
        FROM current_month cm
        LEFT JOIN previous_month pm ON cm.category_id = pm.category_id
        WHERE (
          pm.previous_amount > 0 AND 
          (cm.current_amount - pm.previous_amount) / pm.previous_amount >= 0.25
        ) OR (
          pm.previous_amount = 0 AND cm.current_amount > 1000
        )
      `

      for (const expense of expenseComparison) {
        const increasePercentage = Number(expense.increase_percentage)
        const currentAmount = Number(expense.current_amount)
        const previousAmount = Number(expense.previous_amount)

        if (increasePercentage >= 25) {
          const alert: AlertNotification = {
            type: "expense_anomaly",
            title: `Unusual ${expense.category_name} Expense`,
            message: `${expense.category_name} expenses increased ${increasePercentage}% from last month`,
            severity: increasePercentage >= 50 ? "high" : "medium",
            schoolId,
            data: {
              category: expense.category_name,
              currentAmount,
              previousAmount,
              increasePercentage,
            },
          }

          await this.sendAlert(alert)
        }
      }
    } catch (error) {
      console.error("Error checking expense alerts:", error)
    }
  }

  // Send alert using the notification service
  private static async sendAlert(alert: AlertNotification): Promise<void> {
    try {
      // Send via API endpoint to handle database storage and notifications
      await fetch("/api/notifications/send-alert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(alert),
      })
    } catch (error) {
      console.error("Error sending alert:", error)
    }
  }

  // Run all alert checks
  static async runAllChecks(schoolId: number): Promise<void> {
    console.log(`[ALERTS] Running alert checks for school ${schoolId}`)

    await Promise.all([
      this.checkBudgetAlerts(schoolId),
      this.checkRevenueAlerts(schoolId),
      this.checkExpenseAlerts(schoolId),
    ])

    console.log(`[ALERTS] Alert checks completed for school ${schoolId}`)
  }
}
